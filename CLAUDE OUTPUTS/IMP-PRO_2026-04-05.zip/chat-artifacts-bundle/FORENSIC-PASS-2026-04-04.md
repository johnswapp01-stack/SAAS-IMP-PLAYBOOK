# Forensic Pass — 2026-04-04

## 1. Executive Summary

### What changed
- Re-aligned the repo around one hosted SaaS path in the README, setup guide, environment sample, and CI.
- Added the missing waitlist database migration that the landing page and `/api/waitlist` route already depended on.
- Hardened the waitlist API so it fails closed when service-role configuration is missing and limits waitlist metrics to authenticated owner/admin users.
- Corrected engagement ownership writes to use `org_members.id`, which matches the live schema.
- Replaced the broken seed flow with schema-aligned demo data.
- Added a real `/engagements/new` page so existing navigation and dashboard CTAs resolve to an actual hosted admin flow.
- Reworked the dashboard decision KPI and recent-decision queries to match the live database schema instead of older fields that no longer exist.
- Added a GitHub Actions workflow to validate install, typecheck, and build on every push/PR.

### Why it changed
The repo had several hard conflicts between the active code path and the source-of-truth docs: placeholder setup instructions, missing waitlist persistence, incorrect foreign-key writes, broken seed data, and a dead “new engagement” route. Those issues undermined SaaS clarity, operator trust, and release confidence.

### How it improves the SaaS product
This pass strengthens the canonical hosted product path, reduces admin friction, restores several broken user journeys, and adds baseline release discipline. It does **not** make the product world-class or production-ready on its own.

## 2. Forensic Gap Report

### Must fix before deploy
1. **Build validation is still not fully evidenced in this pass.** TypeScript passed locally, but a clean, conclusive production build result was not captured end-to-end in this environment.
2. **Schema drift remains in other product areas beyond the dashboard and seed path.** Several pages and components still appear to reference older field names or states compared with `001_initial_schema.sql`.
3. **No verified hosted auth/onboarding test run was completed.** Auth pages, organization creation, engagement creation, and billing flows were reviewed in code but not exercised against a live Supabase/Vercel environment.
4. **No proven observability stack exists yet.** The repo has activity logging tables and self-healing tables, but no validated operational monitoring, alert routing, or incident workflow.
5. **Enterprise/GTM claims exceed implemented evidence.** SSO, advanced enterprise controls, and some governance/AI claims remain more documented than shipped.

### Should fix this sprint
1. Replace remaining schema-drifted components with database-accurate implementations.
2. Add a real ESLint configuration instead of using typecheck as the current static-validation fallback.
3. Add CI coverage for E2E smoke tests in a controlled preview environment.
4. Add explicit admin-facing diagnostics for waitlist, billing state, webhook state, and migration/seed status.
5. Tighten role-based checks on all write-heavy admin routes, not only selected routes.

### Nice to have
1. Add hosted admin analytics for onboarding completion, engagement creation, and plan-upgrade funnel.
2. Add operator-facing release notes and rollback playbook docs.
3. Add dedicated help states and guided empty states across dashboard modules.

## 3. Lessons Learned

### What was wrong
- The repo described a SaaS platform but still contained placeholder/manual setup instructions, missing persistence for a live landing-page feature, and runtime code tied to outdated schema assumptions.
- Some admin flows existed in UI copy only, not as working routes.
- Documentation and scripts overstated operational readiness.

### Why it happened
- The codebase evolved from planning/scaffolding documents faster than the checked-in runtime and setup material were reconciled.
- Product, schema, and UI layers were edited in different passes without a strict release gate.

### How it was corrected in this pass
- Replaced placeholder/local-only setup guidance with a concise canonical SaaS setup path.
- Added the missing waitlist migration and locked down the waitlist admin surface.
- Corrected foreign-key ownership writes and replaced broken demo seed data with schema-aligned inserts.
- Added the missing hosted “new engagement” flow and fixed the dashboard’s decision data model.
- Added CI so the repo has a checked-in validation path instead of only narrative claims.

### How to avoid the same problem again
- Treat `supabase/migrations/` as the single schema authority and block merges when UI/API code references fields or statuses that do not exist there.
- Require every new route in navigation or CTAs to have a live implementation before merge.
- Keep README, setup docs, env samples, and workflows aligned in the same PR as any runtime change.
- Do not ship GTM or enterprise claims ahead of validated implementation evidence.

## 4. File-by-File Change Log

| File | Issue | Exact fix | Product impact |
|---|---|---|---|
| `README.md` | README was broad, drifted from code, and not concise SaaS-only guidance | Rewrote to define canonical frontend/backend/deploy path, real env/setup, and known conflicts | Improves product clarity and operator trust |
| `SETUP-INSTRUCTIONS.md` | Placeholder chat-download instructions and Windows path | Replaced with actual engineering/deploy steps tied to this repo | Removes non-canonical/local confusion |
| `.env.example` | Missing required keys, localhost default, and unimplemented fallback provider | Replaced with hosted SaaS-oriented placeholders matching active code paths | Strengthens secure, explicit configuration |
| `package.json` | Broken lint command and stale db helper messages | Added `typecheck`, repointed `lint`, and updated migration/seed helper text | Improves release discipline |
| `supabase/migrations/002_waitlist_and_saas_alignment.sql` | Landing waitlist depended on a table that did not exist | Added waitlist table, indexes, RLS, and update trigger | Restores landing-page persistence path |
| `src/app/api/waitlist/route.ts` | Service-role usage lacked explicit config guards; admin stats auth was confusing/weak | Added fail-closed config checks and owner/admin gating for waitlist metrics | Improves security and admin trust |
| `src/app/api/engagements/create/route.ts` | `owner_id` wrote `auth.users.id` instead of `org_members.id` | Updated membership query and insert payload | Fixes schema-aligned engagement ownership |
| `src/app/(dashboard)/onboarding/page.tsx` | First engagement creation used wrong owner foreign key | Updated membership query and insert payload | Fixes first-run onboarding flow |
| `src/app/(dashboard)/dashboard/page.tsx` | Dashboard queried nonexistent decision fields/statuses and mislabeled KPI | Reworked to use `decision`, `date`, and `active` status | Restores dashboard accuracy |
| `src/app/(dashboard)/engagements/new/page.tsx` | Existing CTAs pointed to a dead route | Added working hosted new-engagement page using the canonical API | Improves admin usability |
| `src/app/api/seed/route.ts` | Seed route targeted outdated schema fields and statuses | Rewrote with valid, schema-aligned demo inserts | Restores guided demo/admin onboarding path |
| `.github/workflows/ci.yml` | No CI/CD validation workflow existed | Added install, typecheck, and build workflow | Improves release discipline and trust |

## 5. SaaS Purity Audit

### Result
**Close but incomplete.**

### Remaining non-canonical or conflicting assumptions
- Local development instructions still necessarily exist for engineers, but production deployment is now clearly documented as hosted SaaS.
- Legacy Gumroad-era files remain in `zOLD-GR-GTM_Items/`. They are isolated, but they still exist in-repo and should remain clearly archival.
- Some source docs still describe capabilities beyond current runtime evidence.
- Additional schema drift may still exist in parts of the active app outside the files corrected here.

No active desktop, tray, Electron, Windows-launcher, or native-wrapper runtime was found in the checked-in app path.

## 6. Admin UX Audit

### Verdict
**Close but incomplete.**

### Why
What improved:
- Hosted onboarding can now create correctly owned engagements.
- The “new engagement” CTA now lands in a real hosted admin flow.
- Waitlist metrics are better protected.
- Setup/docs are less engineering-hostile and less ambiguous.

What still blocks a world-class admin experience:
- Limited diagnostics and recoverability visibility.
- No validated billing/webhook/admin monitoring experience.
- Some admin flows remain scaffold-quality rather than deeply guided.
- Not enough evidence yet that every route is schema-accurate and production-safe.

## 7. End-User / Non-Technical UX Audit

### Verdict
**Not yet acceptable as world-class.**

### Why
Positive signs:
- Landing page, pricing, and signup story are coherent with the SaaS direction.
- Waitlist persistence now has a real backend path.
- The product language remains focused on implementation teams.

What remains incomplete:
- No validated first-run journey with real auth + org + first engagement + first value loop evidence.
- Some workflow depth is still more promised than proven.
- In-product help, empty-state guidance, and trust cues are not consistently mature across modules.

## 8. Release Gate

### Recommendation
**Do not ship.**

### Reasons
- Build success was not conclusively evidenced in this pass.
- Schema drift still appears to remain outside the files fixed here.
- Live auth, deployment, billing, and end-to-end hosted behavior were not validated.
- Documentation is improved, but runtime proof still trails product claims.

## 9. Validation Evidence

### Actually validated
- Repo structure and source-of-truth docs were reviewed.
- `npm install` completed successfully in the container.
- `npm run typecheck` completed successfully.
- `npm run lint` now resolves to the same working typecheck path instead of failing immediately.
- The repo was patched so previously dead routes and missing migrations now exist in code.

### Not claimed
- No live Supabase-backed auth flow was executed.
- No live Stripe checkout/webhook cycle was executed.
- No E2E suite was run successfully.
- No conclusive production build completion was captured.
- No deployment to Vercel was performed.

## 10. Source Conflicts Noted

1. **Free plan engagement limit conflict**
   - Repo behavior: 2 active engagements (`src/app/api/engagements/create/route.ts`, landing/engagement copy)
   - GTM doc: 3 engagements on Free
   - Resolution: kept **2**, because active repo behavior wins until a new product decision is made.

2. **AI fallback conflict**
   - README previously claimed OpenAI fallback
   - Active runtime only implements Anthropic in the code reviewed here
   - Resolution: removed fallback claim from canonical setup/docs.

3. **Setup/deployment conflict**
   - Setup doc previously referenced chat-download placeholders and a Windows extraction path
   - Repo is a hosted web app intended for SaaS delivery
   - Resolution: replaced with repo-native engineering/deploy instructions.
