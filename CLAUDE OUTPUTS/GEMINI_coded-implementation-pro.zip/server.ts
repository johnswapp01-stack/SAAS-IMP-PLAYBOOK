import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import Stripe from "stripe";
import helmet from "helmet";
import cors from "cors";
import rateLimit from "express-rate-limit";
import { z } from "zod";
import { GoogleGenAI } from "@google/genai";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let stripeClient: Stripe | null = null;
let aiClient: GoogleGenAI | null = null;

export function getStripe(): Stripe {
  if (!stripeClient) {
    const key = process.env.STRIPE_SECRET_KEY;
    if (!key) {
      throw new Error('STRIPE_SECRET_KEY environment variable is required');
    }
    stripeClient = new Stripe(key, { apiVersion: '2023-10-16' as any });
  }
  return stripeClient;
}

export function getAI(): GoogleGenAI {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      throw new Error('GEMINI_API_KEY environment variable is required');
    }
    aiClient = new GoogleGenAI({ apiKey: key });
  }
  return aiClient;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Security Middleware
  app.use(helmet({
    contentSecurityPolicy: false, // Disabled for Vite dev server compatibility
  }));
  app.use(cors());
  
  // Rate limiting
  const apiLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // Limit each IP to 100 requests per windowMs
    message: { error: "Too many requests, please try again later." }
  });

  app.use(express.json());

  // API routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Validation schemas
  const portalSessionSchema = z.object({
    orgId: z.string().min(1, "orgId is required"),
  });

  app.post("/api/create-portal-session", apiLimiter, async (req, res) => {
    try {
      const { orgId } = portalSessionSchema.parse(req.body);

      const stripe = getStripe();
      
      // Mock customer creation for demo
      const customer = await stripe.customers.create({
        metadata: { orgId }
      });

      const session = await stripe.billingPortal.sessions.create({
        customer: customer.id,
        return_url: `${process.env.APP_URL || `http://localhost:${PORT}`}/settings`,
      });

      res.json({ url: session.url });
    } catch (error: any) {
      console.error("Stripe error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      res.status(500).json({ error: error.message });
    }
  });

  const runAgentSchema = z.object({
    engagementId: z.string().min(1, "engagementId is required"),
  });

  app.post("/api/run-agent", apiLimiter, async (req, res) => {
    try {
      const { engagementId } = runAgentSchema.parse(req.body);

      const ai = getAI();
      
      // Real AI Call
      const response = await ai.models.generateContent({
        model: "gemini-3.1-pro-preview",
        contents: `Analyze the engagement with ID ${engagementId} and generate a brief status report summary. Assume the project is currently on track but needs a risk review.`,
      });

      res.json({ 
        status: "success", 
        message: "Agent workflow completed successfully.",
        reportId: `rep_${Math.random().toString(36).substr(2, 9)}`,
        aiSummary: response.text
      });
    } catch (error: any) {
      console.error("Agent error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      res.status(500).json({ error: error.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
