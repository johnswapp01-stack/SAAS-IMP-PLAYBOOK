import React, { useState, useEffect, useRef } from 'react';
import { useParams, Link } from 'react-router-dom';
import * as Tabs from '@radix-ui/react-tabs';
import * as Dialog from '@radix-ui/react-dialog';
import { ChevronRight, Users, Target, CheckSquare, FileText, AlertTriangle, Bot, UploadCloud, File, CheckCircle2, Loader2, Plus, ArrowRight, X } from 'lucide-react';
import { cn } from '../lib/utils';
import { supabase } from '../lib/supabase';
import { Engagement, ScopeItem as ScopeItemType, Stakeholder as StakeholderType, RaciItem, ChecklistItem, RiskSignal, StatusReport } from '../types';
import { analyzeDocument } from '../lib/ai';
import { toast } from 'sonner';

export function EngagementDetail() {
  const { id } = useParams<{ id: string }>();
  const [uploadState, setUploadState] = useState<'idle' | 'analyzing' | 'complete'>('idle');
  const [activeTab, setActiveTab] = useState('documents');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);
  
  const [engagement, setEngagement] = useState<Engagement | null>(null);
  const [scopeItems, setScopeItems] = useState<ScopeItemType[]>([]);
  const [stakeholders, setStakeholders] = useState<StakeholderType[]>([]);
  const [raciItems, setRaciItems] = useState<RaciItem[]>([]);
  const [checklists, setChecklists] = useState<ChecklistItem[]>([]);
  const [riskSignals, setRiskSignals] = useState<RiskSignal[]>([]);
  const [reports, setReports] = useState<StatusReport[]>([]);
  const [loading, setLoading] = useState(true);

  // Add Scope Item Modal State
  const [isAddScopeOpen, setIsAddScopeOpen] = useState(false);
  const [newScopeTitle, setNewScopeTitle] = useState('');
  const [newScopePriority, setNewScopePriority] = useState('Must Have');
  const [isAddingScope, setIsAddingScope] = useState(false);

  // Add Stakeholder Modal State
  const [isAddStakeholderOpen, setIsAddStakeholderOpen] = useState(false);
  const [newStakeholderName, setNewStakeholderName] = useState('');
  const [newStakeholderRole, setNewStakeholderRole] = useState('');
  const [newStakeholderEmail, setNewStakeholderEmail] = useState('');
  const [isAddingStakeholder, setIsAddingStakeholder] = useState(false);

  // Add RACI Modal State
  const [isAddRaciOpen, setIsAddRaciOpen] = useState(false);
  const [newRaciTask, setNewRaciTask] = useState('');
  const [newRaciResponsible, setNewRaciResponsible] = useState('');
  const [newRaciAccountable, setNewRaciAccountable] = useState('');
  const [newRaciConsulted, setNewRaciConsulted] = useState('');
  const [newRaciInformed, setNewRaciInformed] = useState('');
  const [isAddingRaci, setIsAddingRaci] = useState(false);

  // Add Checklist Modal State
  const [isAddChecklistOpen, setIsAddChecklistOpen] = useState(false);
  const [newChecklistTask, setNewChecklistTask] = useState('');
  const [isAddingChecklist, setIsAddingChecklist] = useState(false);

  // Add Risk Modal State
  const [isAddRiskOpen, setIsAddRiskOpen] = useState(false);
  const [newRiskDescription, setNewRiskDescription] = useState('');
  const [newRiskSeverity, setNewRiskSeverity] = useState('medium');
  const [newRiskType, setNewRiskType] = useState('timeline');
  const [isAddingRisk, setIsAddingRisk] = useState(false);

  useEffect(() => {
    async function fetchData() {
      if (!id) return;
      
      try {
        const { data: engData, error: engError } = await supabase
          .from('engagements')
          .select('*')
          .eq('id', id)
          .single();
          
        if (engError) throw engError;
        setEngagement(engData);

        // Fetch related data in parallel
        const [
          { data: scopeData },
          { data: stakeholderData },
          { data: raciData },
          { data: checklistData },
          { data: riskData },
          { data: reportData }
        ] = await Promise.all([
          supabase.from('scope_items').select('*').eq('engagement_id', id),
          supabase.from('stakeholders').select('*').eq('engagement_id', id),
          supabase.from('raci_items').select('*').eq('engagement_id', id),
          supabase.from('checklist_items').select('*').eq('engagement_id', id),
          supabase.from('risk_signals').select('*').eq('engagement_id', id),
          supabase.from('status_reports').select('*').eq('engagement_id', id)
        ]);

        setScopeItems(scopeData || []);
        setStakeholders(stakeholderData || []);
        setRaciItems(raciData || []);
        setChecklists(checklistData || []);
        setRiskSignals(riskData || []);
        setReports(reportData || []);

      } catch (err) {
        console.error('Error fetching engagement details:', err);
      } finally {
        setLoading(false);
      }
    }
    
    fetchData();
  }, [id]);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadState('analyzing');
    setUploadError(null);
    
    try {
      const result = await analyzeDocument(file);
      setAnalysisResult(result);
      setUploadState('complete');
    } catch (err: any) {
      console.error('Error analyzing document:', err);
      setUploadError(err.message || 'Failed to analyze document');
      setUploadState('idle');
    }
  };

  const handleApproveAll = async () => {
    if (!analysisResult || !id) return;
    
    try {
      // Insert scope items
      if (analysisResult.scopeItems?.length > 0) {
        const scopePayload = analysisResult.scopeItems.map((item: any) => ({
          engagement_id: id,
          title: item.title,
          priority: item.priority,
          status: 'Not Started'
        }));
        const { data: newScope } = await supabase.from('scope_items').insert(scopePayload).select();
        if (newScope) setScopeItems([...scopeItems, ...newScope]);
      }

      // Insert stakeholders
      if (analysisResult.stakeholders?.length > 0) {
        const stakeholderPayload = analysisResult.stakeholders.map((item: any) => ({
          engagement_id: id,
          name: item.name,
          role: item.role,
          email: item.email || null,
          influence: 'Medium',
        }));
        const { data: newStakeholders } = await supabase.from('stakeholders').insert(stakeholderPayload).select();
        if (newStakeholders) setStakeholders([...stakeholders, ...newStakeholders]);
      }

      // Insert risks
      if (analysisResult.risks?.length > 0) {
        const riskPayload = analysisResult.risks.map((item: any) => ({
          engagement_id: id,
          description: item.description,
          severity: item.severity,
          type: item.type,
          status: 'open'
        }));
        const { data: newRisks } = await supabase.from('risk_signals').insert(riskPayload).select();
        if (newRisks) setRiskSignals([...riskSignals, ...newRisks]);
      }

      setActiveTab('scope');
      setUploadState('idle');
      setAnalysisResult(null);
      toast.success('Document analyzed and data extracted successfully!');
    } catch (err) {
      console.error('Error saving extracted data:', err);
      toast.error('Failed to save extracted data. Please try again.');
    }
  };

  const handleAddScopeItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newScopeTitle.trim() || !id) return;

    setIsAddingScope(true);
    try {
      const { data, error } = await supabase
        .from('scope_items')
        .insert([{
          engagement_id: id,
          title: newScopeTitle,
          priority: newScopePriority,
          status: 'Not Started'
        }])
        .select()
        .single();

      if (error) throw error;
      
      if (data) {
        setScopeItems([...scopeItems, data]);
        setIsAddScopeOpen(false);
        setNewScopeTitle('');
        setNewScopePriority('Must Have');
        toast.success('Scope item added successfully!');
      }
    } catch (err) {
      console.error('Error adding scope item:', err);
      toast.error('Failed to add scope item. Please try again.');
    } finally {
      setIsAddingScope(false);
    }
  };

  const handleAddStakeholder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStakeholderName.trim() || !newStakeholderRole.trim() || !id) return;

    setIsAddingStakeholder(true);
    try {
      const { data, error } = await supabase
        .from('stakeholders')
        .insert([{
          engagement_id: id,
          name: newStakeholderName,
          role: newStakeholderRole,
          email: newStakeholderEmail || null,
          influence: 'Medium'
        }])
        .select()
        .single();

      if (error) throw error;
      
      if (data) {
        setStakeholders([...stakeholders, data]);
        setIsAddStakeholderOpen(false);
        setNewStakeholderName('');
        setNewStakeholderRole('');
        setNewStakeholderEmail('');
        toast.success('Stakeholder added successfully!');
      }
    } catch (err) {
      console.error('Error adding stakeholder:', err);
      toast.error('Failed to add stakeholder. Please try again.');
    } finally {
      setIsAddingStakeholder(false);
    }
  };

  const handleAddRaci = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRaciTask.trim() || !id) return;

    setIsAddingRaci(true);
    try {
      const { data, error } = await supabase
        .from('raci_items')
        .insert([{
          engagement_id: id,
          task: newRaciTask,
          responsible: newRaciResponsible,
          accountable: newRaciAccountable,
          consulted: newRaciConsulted,
          informed: newRaciInformed
        }])
        .select()
        .single();

      if (error) throw error;
      
      if (data) {
        setRaciItems([...raciItems, data]);
        setIsAddRaciOpen(false);
        setNewRaciTask('');
        setNewRaciResponsible('');
        setNewRaciAccountable('');
        setNewRaciConsulted('');
        setNewRaciInformed('');
        toast.success('RACI task added successfully!');
      }
    } catch (err) {
      console.error('Error adding RACI item:', err);
      toast.error('Failed to add RACI item. Please try again.');
    } finally {
      setIsAddingRaci(false);
    }
  };

  const handleAddChecklist = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChecklistTask.trim() || !id) return;

    setIsAddingChecklist(true);
    try {
      const { data, error } = await supabase
        .from('checklist_items')
        .insert([{
          engagement_id: id,
          task: newChecklistTask,
          status: 'pending'
        }])
        .select()
        .single();

      if (error) throw error;
      
      if (data) {
        setChecklists([...checklists, data]);
        setIsAddChecklistOpen(false);
        setNewChecklistTask('');
        toast.success('Checklist item added successfully!');
      }
    } catch (err) {
      console.error('Error adding checklist item:', err);
      toast.error('Failed to add checklist item. Please try again.');
    } finally {
      setIsAddingChecklist(false);
    }
  };

  const handleAddRisk = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRiskDescription.trim() || !id) return;

    setIsAddingRisk(true);
    try {
      const { data, error } = await supabase
        .from('risk_signals')
        .insert([{
          engagement_id: id,
          description: newRiskDescription,
          severity: newRiskSeverity,
          type: newRiskType,
          status: 'open'
        }])
        .select()
        .single();

      if (error) throw error;
      
      if (data) {
        setRiskSignals([...riskSignals, data]);
        setIsAddRiskOpen(false);
        setNewRiskDescription('');
        setNewRiskSeverity('medium');
        setNewRiskType('timeline');
        toast.success('Risk signal added successfully!');
      }
    } catch (err) {
      console.error('Error adding risk:', err);
      toast.error('Failed to add risk. Please try again.');
    } finally {
      setIsAddingRisk(false);
    }
  };

  const [isAgentRunning, setIsAgentRunning] = useState(false);

  const handleRunAgent = async () => {
    setIsAgentRunning(true);
    try {
      const response = await fetch('/api/run-agent', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ engagementId: id }),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to run agent');
      }
      
      toast.success(data.message || 'Agent workflow completed successfully!');
      
      // In a real implementation, this would trigger a refresh of the status reports
      // or update the engagement health based on the agent's findings.
    } catch (err) {
      console.error('Error running agent:', err);
      toast.error('Failed to run agent. Please try again.');
    } finally {
      setIsAgentRunning(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-[400px] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
      </div>
    );
  }

  if (!engagement) {
    return (
      <div className="text-center py-12">
        <h2 className="text-xl font-semibold text-slate-900">Engagement not found</h2>
        <p className="text-slate-500 mt-2">The engagement you're looking for doesn't exist or you don't have access.</p>
        <Link to="/engagements" className="text-indigo-600 hover:text-indigo-800 font-medium mt-4 inline-block">
          Back to Engagements
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Breadcrumbs & Header */}
      <div>
        <nav className="flex items-center text-sm text-slate-500 mb-4">
          <Link to="/engagements" className="hover:text-slate-900 transition-colors">Engagements</Link>
          <ChevronRight className="w-4 h-4 mx-1" />
          <span className="text-slate-900 font-medium">{engagement.name}</span>
        </nav>
        
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">{engagement.name}</h1>
            <p className="text-slate-500 mt-1">{engagement.client_name}</p>
          </div>
          <div className="flex items-center gap-3">
            <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-slate-100 text-slate-800 border border-slate-200 capitalize">
              {engagement.status.replace('_', ' ')}
            </span>
            <span className={cn(
              "inline-flex items-center px-3 py-1 rounded-full text-sm font-medium border capitalize",
              engagement.health === 'green' ? 'bg-green-100 text-green-700 border-green-200' :
              engagement.health === 'yellow' ? 'bg-amber-100 text-amber-700 border-amber-200' :
              'bg-red-100 text-red-700 border-red-200'
            )}>
              {engagement.health === 'green' ? 'On Track' : engagement.health === 'yellow' ? 'At Risk' : 'Critical'}
            </span>
            <button 
              onClick={handleRunAgent}
              disabled={isAgentRunning}
              className="inline-flex items-center justify-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isAgentRunning ? <Loader2 className="w-4 h-4 animate-spin" /> : <Bot className="w-4 h-4" />}
              {isAgentRunning ? 'Running...' : 'Run Agent'}
            </button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <Tabs.Root value={activeTab} onValueChange={setActiveTab} className="flex flex-col">
        <Tabs.List className="flex overflow-x-auto border-b border-slate-200 hide-scrollbar mb-6">
          <TabTrigger value="documents" icon={FileText}>Documents & AI</TabTrigger>
          <TabTrigger value="scope" icon={Target}>Scope (MoSCoW)</TabTrigger>
          <TabTrigger value="stakeholders" icon={Users}>Stakeholders</TabTrigger>
          <TabTrigger value="raci" icon={Users}>RACI</TabTrigger>
          <TabTrigger value="checklist" icon={CheckSquare}>Checklists</TabTrigger>
          <TabTrigger value="risks" icon={AlertTriangle}>Risk Signals</TabTrigger>
          <TabTrigger value="reports" icon={FileText}>Reports</TabTrigger>
        </Tabs.List>

        <Tabs.Content value="documents" className="focus:outline-none">
          <div className="space-y-6">
            {uploadState === 'idle' && (
              <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-8 text-center">
                <div className="max-w-xl mx-auto">
                  <div className="w-16 h-16 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                    <UploadCloud className="w-8 h-8" />
                  </div>
                  <h3 className="text-xl font-semibold text-slate-900 mb-2">Upload Statement of Work</h3>
                  <p className="text-slate-500 mb-8">
                    Upload your SOW, contract, or requirements PDF. Our AI will automatically extract scope items, stakeholders, and milestones to bootstrap your engagement.
                  </p>
                  
                  <input 
                    type="file" 
                    ref={fileInputRef} 
                    onChange={handleFileChange} 
                    className="hidden" 
                    accept="application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                  />
                  
                  <div 
                    onClick={() => fileInputRef.current?.click()}
                    className="border-2 border-dashed border-slate-300 rounded-xl p-10 hover:bg-slate-50 hover:border-indigo-400 transition-colors cursor-pointer group"
                  >
                    <File className="w-10 h-10 text-slate-400 group-hover:text-indigo-500 mx-auto mb-4 transition-colors" />
                    <p className="text-sm font-medium text-slate-700">Click to upload or drag and drop</p>
                    <p className="text-xs text-slate-500 mt-1">PDF, DOCX up to 50MB</p>
                  </div>
                  {uploadError && (
                    <p className="text-sm text-red-600 mt-4">{uploadError}</p>
                  )}
                </div>
              </div>
            )}

            {uploadState === 'analyzing' && (
              <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-12 text-center">
                <Loader2 className="w-12 h-12 text-indigo-600 animate-spin mx-auto mb-6" />
                <h3 className="text-xl font-semibold text-slate-900 mb-2">Analyzing Document...</h3>
                <p className="text-slate-500 max-w-md mx-auto">
                  The Documentation Agent is reading the SOW, extracting MoSCoW scope items, identifying key stakeholders, and drafting the initial project plan.
                </p>
                
                <div className="max-w-md mx-auto mt-8 space-y-3 text-left">
                  <div className="flex items-center gap-3 text-sm text-slate-600 bg-slate-50 p-3 rounded-lg border border-slate-100">
                    <CheckCircle2 className="w-4 h-4 text-green-500" />
                    <span>Document parsed successfully</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-slate-600 bg-slate-50 p-3 rounded-lg border border-slate-100">
                    <Loader2 className="w-4 h-4 text-indigo-500 animate-spin" />
                    <span>Extracting deliverables and scope...</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-slate-400 bg-slate-50 p-3 rounded-lg border border-slate-100">
                    <div className="w-4 h-4 rounded-full border-2 border-slate-200" />
                    <span>Identifying stakeholders...</span>
                  </div>
                </div>
              </div>
            )}

            {uploadState === 'complete' && analysisResult && (
              <div className="space-y-6">
                <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-green-50 text-green-600 rounded-xl flex items-center justify-center shrink-0">
                      <FileText className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-slate-900">Analysis Complete</h3>
                      <p className="text-sm text-slate-500">{analysisResult.scopeItems?.length || 0} scope items, {analysisResult.stakeholders?.length || 0} stakeholders found</p>
                    </div>
                  </div>
                  <div className="flex gap-3 w-full sm:w-auto">
                    <button 
                      onClick={() => {
                        setUploadState('idle');
                        setAnalysisResult(null);
                      }}
                      className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
                    >
                      Upload Another
                    </button>
                    <button 
                      onClick={handleApproveAll}
                      className="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors shadow-sm"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      Approve All & Import
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Extracted Scope */}
                  <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden flex flex-col">
                    <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
                      <h4 className="font-semibold text-slate-900 flex items-center gap-2">
                        <Target className="w-4 h-4 text-indigo-500" />
                        Extracted Scope (MoSCoW)
                      </h4>
                      <span className="text-xs font-medium bg-indigo-100 text-indigo-700 px-2 py-1 rounded-full">{analysisResult.scopeItems?.length || 0} Items</span>
                    </div>
                    <div className="p-4 space-y-3 overflow-y-auto max-h-[400px]">
                      {analysisResult.scopeItems?.map((item: any, i: number) => (
                        <ExtractedItem 
                          key={i} 
                          title={item.title} 
                          badge={item.priority} 
                          badgeColor={
                            item.priority === 'Must Have' ? 'red' : 
                            item.priority === 'Should Have' ? 'amber' : 
                            item.priority === 'Could Have' ? 'blue' : 'slate'
                          } 
                        />
                      ))}
                    </div>
                  </div>

                  {/* Extracted Stakeholders & Risks */}
                  <div className="space-y-6">
                    <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
                      <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
                        <h4 className="font-semibold text-slate-900 flex items-center gap-2">
                          <Users className="w-4 h-4 text-indigo-500" />
                          Identified Stakeholders
                        </h4>
                        <span className="text-xs font-medium bg-indigo-100 text-indigo-700 px-2 py-1 rounded-full">{analysisResult.stakeholders?.length || 0} People</span>
                      </div>
                      <div className="p-4 space-y-3">
                        {analysisResult.stakeholders?.map((s: any, i: number) => (
                          <ExtractedStakeholder key={i} name={s.name} role={s.role} email={s.email || ''} />
                        ))}
                      </div>
                    </div>

                    <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
                      <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
                        <h4 className="font-semibold text-slate-900 flex items-center gap-2">
                          <AlertTriangle className="w-4 h-4 text-amber-500" />
                          Potential Risks Detected
                        </h4>
                      </div>
                      <div className="p-4 space-y-3">
                        {analysisResult.risks?.map((risk: any, i: number) => (
                          <div key={i} className="flex gap-3 p-3 bg-amber-50 border border-amber-100 rounded-lg">
                            <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
                            <div>
                              <h5 className="text-sm font-medium text-amber-900 capitalize">{risk.type} Risk</h5>
                              <p className="text-xs text-amber-700 mt-1">{risk.description}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </Tabs.Content>

        <Tabs.Content value="scope" className="focus:outline-none">
          <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-slate-900">Scope Items</h3>
              
              <Dialog.Root open={isAddScopeOpen} onOpenChange={setIsAddScopeOpen}>
                <Dialog.Trigger asChild>
                  <button className="text-sm font-medium text-indigo-600 hover:text-indigo-700 flex items-center gap-1">
                    <Plus className="w-4 h-4" /> Add Item
                  </button>
                </Dialog.Trigger>
                <Dialog.Portal>
                  <Dialog.Overlay className="fixed inset-0 bg-black/50 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 z-50" />
                  <Dialog.Content className="fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border border-slate-200 bg-white p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-xl">
                    <div className="flex flex-col space-y-1.5 text-center sm:text-left">
                      <Dialog.Title className="text-lg font-semibold leading-none tracking-tight text-slate-900">
                        Add Scope Item
                      </Dialog.Title>
                      <Dialog.Description className="text-sm text-slate-500">
                        Define a new deliverable or requirement for this engagement.
                      </Dialog.Description>
                    </div>
                    
                    <form onSubmit={handleAddScopeItem} className="space-y-4 py-4">
                      <div className="space-y-2">
                        <label htmlFor="title" className="text-sm font-medium text-slate-900">
                          Title
                        </label>
                        <input
                          id="title"
                          value={newScopeTitle}
                          onChange={(e) => setNewScopeTitle(e.target.value)}
                          className="flex h-10 w-full rounded-md border border-slate-300 bg-transparent px-3 py-2 text-sm placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent disabled:cursor-not-allowed disabled:opacity-50"
                          placeholder="e.g., SSO Integration"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="priority" className="text-sm font-medium text-slate-900">
                          Priority (MoSCoW)
                        </label>
                        <select
                          id="priority"
                          value={newScopePriority}
                          onChange={(e) => setNewScopePriority(e.target.value)}
                          className="flex h-10 w-full rounded-md border border-slate-300 bg-transparent px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                        >
                          <option value="Must Have">Must Have</option>
                          <option value="Should Have">Should Have</option>
                          <option value="Could Have">Could Have</option>
                          <option value="Won't Have">Won't Have</option>
                        </select>
                      </div>
                      
                      <div className="flex justify-end gap-3 pt-4">
                        <Dialog.Close asChild>
                          <button
                            type="button"
                            className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
                          >
                            Cancel
                          </button>
                        </Dialog.Close>
                        <button
                          type="submit"
                          disabled={isAddingScope || !newScopeTitle.trim()}
                          className="inline-flex items-center justify-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          {isAddingScope ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            'Add Item'
                          )}
                        </button>
                      </div>
                    </form>
                    
                    <Dialog.Close className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-white transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-slate-100 data-[state=open]:text-slate-500">
                      <X className="h-4 w-4" />
                      <span className="sr-only">Close</span>
                    </Dialog.Close>
                  </Dialog.Content>
                </Dialog.Portal>
              </Dialog.Root>
            </div>
            
            <div className="space-y-4">
              {scopeItems.length === 0 ? (
                <p className="text-slate-500 text-center py-8">No scope items added yet.</p>
              ) : (
                scopeItems.map(item => (
                  <ScopeItem key={item.id} title={item.title} priority={item.priority} status={item.status} />
                ))
              )}
            </div>
          </div>
        </Tabs.Content>

        <Tabs.Content value="stakeholders" className="focus:outline-none">
           <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-slate-900">Stakeholder Registry</h3>
              
              <Dialog.Root open={isAddStakeholderOpen} onOpenChange={setIsAddStakeholderOpen}>
                <Dialog.Trigger asChild>
                  <button className="text-sm font-medium text-indigo-600 hover:text-indigo-700 flex items-center gap-1">
                    <Plus className="w-4 h-4" /> Add Stakeholder
                  </button>
                </Dialog.Trigger>
                <Dialog.Portal>
                  <Dialog.Overlay className="fixed inset-0 bg-black/50 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 z-50" />
                  <Dialog.Content className="fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border border-slate-200 bg-white p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-xl">
                    <div className="flex flex-col space-y-1.5 text-center sm:text-left">
                      <Dialog.Title className="text-lg font-semibold leading-none tracking-tight text-slate-900">
                        Add Stakeholder
                      </Dialog.Title>
                    </div>
                    
                    <form onSubmit={handleAddStakeholder} className="space-y-4 py-4">
                      <div className="space-y-2">
                        <label htmlFor="name" className="text-sm font-medium text-slate-900">Name</label>
                        <input
                          id="name"
                          value={newStakeholderName}
                          onChange={(e) => setNewStakeholderName(e.target.value)}
                          className="flex h-10 w-full rounded-md border border-slate-300 bg-transparent px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="role" className="text-sm font-medium text-slate-900">Role</label>
                        <input
                          id="role"
                          value={newStakeholderRole}
                          onChange={(e) => setNewStakeholderRole(e.target.value)}
                          className="flex h-10 w-full rounded-md border border-slate-300 bg-transparent px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="email" className="text-sm font-medium text-slate-900">Email (Optional)</label>
                        <input
                          id="email"
                          type="email"
                          value={newStakeholderEmail}
                          onChange={(e) => setNewStakeholderEmail(e.target.value)}
                          className="flex h-10 w-full rounded-md border border-slate-300 bg-transparent px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                        />
                      </div>
                      
                      <div className="flex justify-end gap-3 pt-4">
                        <Dialog.Close asChild>
                          <button type="button" className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors">
                            Cancel
                          </button>
                        </Dialog.Close>
                        <button type="submit" disabled={isAddingStakeholder || !newStakeholderName.trim() || !newStakeholderRole.trim()} className="inline-flex items-center justify-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed">
                          {isAddingStakeholder ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Add Stakeholder'}
                        </button>
                      </div>
                    </form>
                    <Dialog.Close className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-white transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-slate-100 data-[state=open]:text-slate-500">
                      <X className="h-4 w-4" />
                      <span className="sr-only">Close</span>
                    </Dialog.Close>
                  </Dialog.Content>
                </Dialog.Portal>
              </Dialog.Root>
            </div>
            {stakeholders.length === 0 ? (
              <p className="text-slate-500 text-center py-8">No stakeholders added yet.</p>
            ) : (
              <div className="space-y-4">
                {stakeholders.map(s => (
                  <ExtractedStakeholder key={s.id} name={s.name} role={s.role} email={s.email || ''} />
                ))}
              </div>
            )}
          </div>
        </Tabs.Content>
        
        <Tabs.Content value="raci" className="focus:outline-none">
          <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-slate-900">RACI Matrix</h3>
              
              <Dialog.Root open={isAddRaciOpen} onOpenChange={setIsAddRaciOpen}>
                <Dialog.Trigger asChild>
                  <button className="text-sm font-medium text-indigo-600 hover:text-indigo-700 flex items-center gap-1">
                    <Plus className="w-4 h-4" /> Add Task
                  </button>
                </Dialog.Trigger>
                <Dialog.Portal>
                  <Dialog.Overlay className="fixed inset-0 bg-black/50 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 z-50" />
                  <Dialog.Content className="fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border border-slate-200 bg-white p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-xl">
                    <div className="flex flex-col space-y-1.5 text-center sm:text-left">
                      <Dialog.Title className="text-lg font-semibold leading-none tracking-tight text-slate-900">
                        Add RACI Task
                      </Dialog.Title>
                    </div>
                    
                    <form onSubmit={handleAddRaci} className="space-y-4 py-4">
                      <div className="space-y-2">
                        <label htmlFor="task" className="text-sm font-medium text-slate-900">Task</label>
                        <input
                          id="task"
                          value={newRaciTask}
                          onChange={(e) => setNewRaciTask(e.target.value)}
                          className="flex h-10 w-full rounded-md border border-slate-300 bg-transparent px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                          required
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label htmlFor="responsible" className="text-sm font-medium text-slate-900">Responsible</label>
                          <input
                            id="responsible"
                            value={newRaciResponsible}
                            onChange={(e) => setNewRaciResponsible(e.target.value)}
                            className="flex h-10 w-full rounded-md border border-slate-300 bg-transparent px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                          />
                        </div>
                        <div className="space-y-2">
                          <label htmlFor="accountable" className="text-sm font-medium text-slate-900">Accountable</label>
                          <input
                            id="accountable"
                            value={newRaciAccountable}
                            onChange={(e) => setNewRaciAccountable(e.target.value)}
                            className="flex h-10 w-full rounded-md border border-slate-300 bg-transparent px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                          />
                        </div>
                        <div className="space-y-2">
                          <label htmlFor="consulted" className="text-sm font-medium text-slate-900">Consulted</label>
                          <input
                            id="consulted"
                            value={newRaciConsulted}
                            onChange={(e) => setNewRaciConsulted(e.target.value)}
                            className="flex h-10 w-full rounded-md border border-slate-300 bg-transparent px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                          />
                        </div>
                        <div className="space-y-2">
                          <label htmlFor="informed" className="text-sm font-medium text-slate-900">Informed</label>
                          <input
                            id="informed"
                            value={newRaciInformed}
                            onChange={(e) => setNewRaciInformed(e.target.value)}
                            className="flex h-10 w-full rounded-md border border-slate-300 bg-transparent px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                          />
                        </div>
                      </div>
                      
                      <div className="flex justify-end gap-3 pt-4">
                        <Dialog.Close asChild>
                          <button type="button" className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors">
                            Cancel
                          </button>
                        </Dialog.Close>
                        <button type="submit" disabled={isAddingRaci || !newRaciTask.trim()} className="inline-flex items-center justify-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed">
                          {isAddingRaci ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Add Task'}
                        </button>
                      </div>
                    </form>
                    <Dialog.Close className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-white transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-slate-100 data-[state=open]:text-slate-500">
                      <X className="h-4 w-4" />
                      <span className="sr-only">Close</span>
                    </Dialog.Close>
                  </Dialog.Content>
                </Dialog.Portal>
              </Dialog.Root>
            </div>
            {raciItems.length === 0 ? (
              <p className="text-slate-500 text-center py-8">No RACI items added yet.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm whitespace-nowrap">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-500">
                    <tr>
                      <th className="px-4 py-3 font-medium">Task</th>
                      <th className="px-4 py-3 font-medium">Responsible</th>
                      <th className="px-4 py-3 font-medium">Accountable</th>
                      <th className="px-4 py-3 font-medium">Consulted</th>
                      <th className="px-4 py-3 font-medium">Informed</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {raciItems.map(item => (
                      <tr key={item.id}>
                        <td className="px-4 py-3 font-medium text-slate-900">{item.task}</td>
                        <td className="px-4 py-3 text-slate-600">{item.responsible}</td>
                        <td className="px-4 py-3 text-slate-600">{item.accountable}</td>
                        <td className="px-4 py-3 text-slate-600">{item.consulted}</td>
                        <td className="px-4 py-3 text-slate-600">{item.informed}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </Tabs.Content>

        <Tabs.Content value="checklist" className="focus:outline-none">
          <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-slate-900">Checklists</h3>
              
              <Dialog.Root open={isAddChecklistOpen} onOpenChange={setIsAddChecklistOpen}>
                <Dialog.Trigger asChild>
                  <button className="text-sm font-medium text-indigo-600 hover:text-indigo-700 flex items-center gap-1">
                    <Plus className="w-4 h-4" /> Add Item
                  </button>
                </Dialog.Trigger>
                <Dialog.Portal>
                  <Dialog.Overlay className="fixed inset-0 bg-black/50 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 z-50" />
                  <Dialog.Content className="fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border border-slate-200 bg-white p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-xl">
                    <div className="flex flex-col space-y-1.5 text-center sm:text-left">
                      <Dialog.Title className="text-lg font-semibold leading-none tracking-tight text-slate-900">
                        Add Checklist Item
                      </Dialog.Title>
                    </div>
                    
                    <form onSubmit={handleAddChecklist} className="space-y-4 py-4">
                      <div className="space-y-2">
                        <label htmlFor="checklistTask" className="text-sm font-medium text-slate-900">Task</label>
                        <input
                          id="checklistTask"
                          value={newChecklistTask}
                          onChange={(e) => setNewChecklistTask(e.target.value)}
                          className="flex h-10 w-full rounded-md border border-slate-300 bg-transparent px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                          required
                        />
                      </div>
                      
                      <div className="flex justify-end gap-3 pt-4">
                        <Dialog.Close asChild>
                          <button type="button" className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors">
                            Cancel
                          </button>
                        </Dialog.Close>
                        <button type="submit" disabled={isAddingChecklist || !newChecklistTask.trim()} className="inline-flex items-center justify-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed">
                          {isAddingChecklist ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Add Item'}
                        </button>
                      </div>
                    </form>
                    <Dialog.Close className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-white transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-slate-100 data-[state=open]:text-slate-500">
                      <X className="h-4 w-4" />
                      <span className="sr-only">Close</span>
                    </Dialog.Close>
                  </Dialog.Content>
                </Dialog.Portal>
              </Dialog.Root>
            </div>
            {checklists.length === 0 ? (
              <p className="text-slate-500 text-center py-8">No checklist items added yet.</p>
            ) : (
              <div className="space-y-3">
                {checklists.map(item => (
                  <div key={item.id} className="flex items-center gap-3 p-3 border border-slate-200 rounded-lg">
                    <input type="checkbox" checked={item.status === 'completed'} readOnly className="w-4 h-4 text-indigo-600 rounded border-slate-300" />
                    <span className={cn("text-sm", item.status === 'completed' ? "text-slate-400 line-through" : "text-slate-700")}>{item.task}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </Tabs.Content>

        <Tabs.Content value="risks" className="focus:outline-none">
          <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-slate-900">Risk Signals</h3>
              
              <Dialog.Root open={isAddRiskOpen} onOpenChange={setIsAddRiskOpen}>
                <Dialog.Trigger asChild>
                  <button className="text-sm font-medium text-indigo-600 hover:text-indigo-700 flex items-center gap-1">
                    <Plus className="w-4 h-4" /> Add Risk
                  </button>
                </Dialog.Trigger>
                <Dialog.Portal>
                  <Dialog.Overlay className="fixed inset-0 bg-black/50 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 z-50" />
                  <Dialog.Content className="fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border border-slate-200 bg-white p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-xl">
                    <div className="flex flex-col space-y-1.5 text-center sm:text-left">
                      <Dialog.Title className="text-lg font-semibold leading-none tracking-tight text-slate-900">
                        Add Risk Signal
                      </Dialog.Title>
                    </div>
                    
                    <form onSubmit={handleAddRisk} className="space-y-4 py-4">
                      <div className="space-y-2">
                        <label htmlFor="riskDescription" className="text-sm font-medium text-slate-900">Description</label>
                        <textarea
                          id="riskDescription"
                          value={newRiskDescription}
                          onChange={(e) => setNewRiskDescription(e.target.value)}
                          className="flex min-h-[80px] w-full rounded-md border border-slate-300 bg-transparent px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                          required
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label htmlFor="riskSeverity" className="text-sm font-medium text-slate-900">Severity</label>
                          <select
                            id="riskSeverity"
                            value={newRiskSeverity}
                            onChange={(e) => setNewRiskSeverity(e.target.value)}
                            className="flex h-10 w-full rounded-md border border-slate-300 bg-transparent px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                          >
                            <option value="low">Low</option>
                            <option value="medium">Medium</option>
                            <option value="high">High</option>
                            <option value="critical">Critical</option>
                          </select>
                        </div>
                        <div className="space-y-2">
                          <label htmlFor="riskType" className="text-sm font-medium text-slate-900">Type</label>
                          <select
                            id="riskType"
                            value={newRiskType}
                            onChange={(e) => setNewRiskType(e.target.value)}
                            className="flex h-10 w-full rounded-md border border-slate-300 bg-transparent px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                          >
                            <option value="timeline">Timeline</option>
                            <option value="scope">Scope</option>
                            <option value="budget">Budget</option>
                            <option value="stakeholder">Stakeholder</option>
                            <option value="technical">Technical</option>
                            <option value="resource">Resource</option>
                          </select>
                        </div>
                      </div>
                      
                      <div className="flex justify-end gap-3 pt-4">
                        <Dialog.Close asChild>
                          <button type="button" className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors">
                            Cancel
                          </button>
                        </Dialog.Close>
                        <button type="submit" disabled={isAddingRisk || !newRiskDescription.trim()} className="inline-flex items-center justify-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed">
                          {isAddingRisk ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Add Risk'}
                        </button>
                      </div>
                    </form>
                    <Dialog.Close className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-white transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-slate-100 data-[state=open]:text-slate-500">
                      <X className="h-4 w-4" />
                      <span className="sr-only">Close</span>
                    </Dialog.Close>
                  </Dialog.Content>
                </Dialog.Portal>
              </Dialog.Root>
            </div>
            {riskSignals.length === 0 ? (
              <p className="text-slate-500 text-center py-8">No risk signals detected or added.</p>
            ) : (
              <div className="space-y-4">
                {riskSignals.map(risk => (
                  <div key={risk.id} className="flex gap-3 p-4 border border-slate-200 rounded-lg">
                    <AlertTriangle className={cn("w-5 h-5 shrink-0", 
                      risk.severity === 'critical' ? "text-red-600" :
                      risk.severity === 'high' ? "text-orange-500" :
                      risk.severity === 'medium' ? "text-amber-500" : "text-blue-500"
                    )} />
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-medium text-slate-900 capitalize">{risk.type} Risk</h4>
                        <span className={cn("text-xs px-2 py-0.5 rounded-full font-medium border capitalize",
                          risk.severity === 'critical' ? "bg-red-50 text-red-700 border-red-200" :
                          risk.severity === 'high' ? "bg-orange-50 text-orange-700 border-orange-200" :
                          risk.severity === 'medium' ? "bg-amber-50 text-amber-700 border-amber-200" : "bg-blue-50 text-blue-700 border-blue-200"
                        )}>{risk.severity}</span>
                      </div>
                      <p className="text-sm text-slate-600 mt-1">{risk.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </Tabs.Content>

        <Tabs.Content value="reports" className="focus:outline-none">
          <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-slate-900">Reports</h3>
              <button className="text-sm font-medium text-indigo-600 hover:text-indigo-700 flex items-center gap-1">
                <Plus className="w-4 h-4" /> Generate Report
              </button>
            </div>
            {reports.length === 0 ? (
              <p className="text-slate-500 text-center py-8">No reports generated yet.</p>
            ) : (
              <div className="space-y-4">
                {reports.map(report => (
                  <div key={report.id} className="flex items-center justify-between p-4 border border-slate-200 rounded-lg">
                    <div className="flex items-center gap-3">
                      <FileText className="w-5 h-5 text-slate-400" />
                      <div>
                        <h4 className="font-medium text-slate-900 capitalize">{report.type} Report</h4>
                        <p className="text-xs text-slate-500 mt-0.5">{new Date(report.report_date).toLocaleDateString()}</p>
                      </div>
                    </div>
                    <span className="text-xs font-medium bg-slate-100 text-slate-700 px-2.5 py-1 rounded-md capitalize border border-slate-200">
                      {report.status}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </Tabs.Content>
      </Tabs.Root>
    </div>
  );
}

function TabTrigger({ value, children, icon: Icon }: { value: string, children: React.ReactNode, icon: any }) {
  return (
    <Tabs.Trigger 
      value={value}
      className="flex items-center gap-2 px-4 py-3 text-sm font-medium text-slate-500 border-b-2 border-transparent hover:text-slate-700 data-[state=active]:text-indigo-600 data-[state=active]:border-indigo-600 whitespace-nowrap transition-colors outline-none"
    >
      <Icon className="w-4 h-4" />
      {children}
    </Tabs.Trigger>
  );
}

function ScopeItem({ title, priority, status }: { title: string, priority: string, status: string }) {
  const priorityColors: Record<string, string> = {
    'Must Have': 'bg-red-50 text-red-700 border-red-200',
    'Should Have': 'bg-amber-50 text-amber-700 border-amber-200',
    'Could Have': 'bg-blue-50 text-blue-700 border-blue-200',
    'Won\'t Have': 'bg-slate-50 text-slate-700 border-slate-200',
  };

  return (
    <div className="flex items-center justify-between p-4 border border-slate-200 rounded-lg hover:border-slate-300 transition-colors">
      <div>
        <h4 className="font-medium text-slate-900">{title}</h4>
        <p className="text-sm text-slate-500 mt-1">Status: {status}</p>
      </div>
      <span className={cn("px-2.5 py-1 rounded-md text-xs font-medium border", priorityColors[priority] || priorityColors['Won\'t Have'])}>
        {priority}
      </span>
    </div>
  );
}

function ExtractedItem({ title, badge, badgeColor }: { title: string, badge: string, badgeColor: 'red' | 'amber' | 'blue' | 'slate' }) {
  const colors = {
    red: 'bg-red-50 text-red-700 border-red-200',
    amber: 'bg-amber-50 text-amber-700 border-amber-200',
    blue: 'bg-blue-50 text-blue-700 border-blue-200',
    slate: 'bg-slate-50 text-slate-700 border-slate-200',
  };

  return (
    <div className="flex items-center justify-between p-3 border border-slate-100 bg-white rounded-lg hover:border-indigo-200 transition-colors group cursor-pointer">
      <div className="flex items-center gap-3">
        <div className="w-5 h-5 rounded border border-slate-300 flex items-center justify-center group-hover:border-indigo-500">
          <CheckSquare className="w-3 h-3 text-transparent group-hover:text-indigo-500" />
        </div>
        <span className="text-sm font-medium text-slate-700 group-hover:text-slate-900">{title}</span>
      </div>
      <span className={cn("px-2 py-0.5 rounded text-[10px] font-semibold border uppercase tracking-wider", colors[badgeColor])}>
        {badge}
      </span>
    </div>
  );
}

function ExtractedStakeholder({ name, role, email }: { name: string, role: string, email: string }) {
  return (
    <div className="flex items-center justify-between p-3 border border-slate-100 bg-white rounded-lg hover:border-indigo-200 transition-colors cursor-pointer">
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 font-medium text-xs">
          {name.split(' ').map(n => n[0]).join('')}
        </div>
        <div>
          <p className="text-sm font-medium text-slate-900">{name}</p>
          <p className="text-xs text-slate-500">{email}</p>
        </div>
      </div>
      <span className="text-xs font-medium text-slate-600 bg-slate-100 px-2 py-1 rounded-md">
        {role}
      </span>
    </div>
  );
}
