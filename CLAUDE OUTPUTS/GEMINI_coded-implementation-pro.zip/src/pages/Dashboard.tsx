import React, { useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { Briefcase, AlertTriangle, CheckCircle2, Clock, Loader2 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useOrg } from '../hooks/useOrg';

export function Dashboard() {
  const { organization } = useOrg();
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    active: 0,
    atRisk: 0,
    completed: 0,
    agentTasks: 0
  });
  
  const [healthData, setHealthData] = useState([
    { name: 'On Track', value: 0, fill: '#22c55e' },
    { name: 'At Risk', value: 0, fill: '#eab308' },
    { name: 'Critical', value: 0, fill: '#ef4444' },
  ]);

  const activityData = [
    { name: 'Mon', tasks: 12 },
    { name: 'Tue', tasks: 19 },
    { name: 'Wed', tasks: 15 },
    { name: 'Thu', tasks: 22 },
    { name: 'Fri', tasks: 18 },
  ];

  useEffect(() => {
    async function fetchDashboardData() {
      if (!organization) return;
      
      try {
        const { data: engagements, error } = await supabase
          .from('engagements')
          .select('status, health')
          .eq('org_id', organization.id);
          
        if (error) throw error;
        
        if (engagements) {
          const active = engagements.filter(e => e.status !== 'complete').length;
          const completed = engagements.filter(e => e.status === 'complete').length;
          const atRisk = engagements.filter(e => e.health === 'yellow' || e.health === 'red').length;
          
          const green = engagements.filter(e => e.health === 'green').length;
          const yellow = engagements.filter(e => e.health === 'yellow').length;
          const red = engagements.filter(e => e.health === 'red').length;
          
          setStats({
            active,
            atRisk,
            completed,
            agentTasks: 845 // Mock for now until agent_tasks table is used
          });
          
          setHealthData([
            { name: 'On Track', value: green, fill: '#22c55e' },
            { name: 'At Risk', value: yellow, fill: '#eab308' },
            { name: 'Critical', value: red, fill: '#ef4444' },
          ]);
        }
      } catch (err) {
        console.error('Error fetching dashboard data:', err);
      } finally {
        setLoading(false);
      }
    }
    
    fetchDashboardData();
  }, [organization]);

  if (loading) {
    return (
      <div className="min-h-[400px] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Dashboard</h1>
        <p className="text-slate-500 mt-1">Overview of your organization's implementations.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Active Engagements" value={stats.active} icon={Briefcase} trend="Current" />
        <StatCard title="At Risk" value={stats.atRisk} icon={AlertTriangle} trend="Needs attention" trendColor="text-amber-600" />
        <StatCard title="Completed" value={stats.completed} icon={CheckCircle2} trend="Total" />
        <StatCard title="Agent Tasks Run" value={stats.agentTasks} icon={Clock} trend="120 hrs saved" trendColor="text-indigo-600" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-semibold text-slate-900 mb-6">Engagement Health</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={healthData} layout="vertical" margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e2e8f0" />
                <XAxis type="number" hide />
                <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} width={80} />
                <Tooltip cursor={{fill: '#f8fafc'}} contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}} />
                <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={32} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-semibold text-slate-900 mb-6">AI Agent Activity</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={activityData} margin={{ top: 5, right: 20, left: -20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b'}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b'}} />
                <Tooltip contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}} />
                <Line type="monotone" dataKey="tasks" stroke="#6366f1" strokeWidth={3} dot={{r: 4, fill: '#6366f1', strokeWidth: 2, stroke: '#fff'}} activeDot={{r: 6}} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({ title, value, icon: Icon, trend, trendColor = "text-slate-500" }: any) {
  return (
    <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-medium text-slate-500">{title}</h3>
        <div className="w-8 h-8 rounded-lg bg-slate-50 flex items-center justify-center">
          <Icon className="w-4 h-4 text-slate-600" />
        </div>
      </div>
      <div className="mt-auto">
        <p className="text-3xl font-bold text-slate-900">{value}</p>
        <p className={`text-sm mt-1 font-medium ${trendColor}`}>{trend}</p>
      </div>
    </div>
  );
}
