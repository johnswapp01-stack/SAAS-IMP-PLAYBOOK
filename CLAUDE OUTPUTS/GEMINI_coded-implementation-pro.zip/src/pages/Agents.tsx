import React from 'react';
import { Bot, FileText, MessageSquare, TestTube, Database, Settings, BarChart2 } from 'lucide-react';

const agents = [
  { id: 'doc', name: 'Documentation Agent', icon: FileText, desc: 'Generates requirements docs, meeting agendas, and handoff documents.', mode: 'Propose-and-wait' },
  { id: 'comm', name: 'Communication Agent', icon: MessageSquare, desc: 'Drafts status updates, escalation emails, and go-live announcements.', mode: 'Propose-and-wait' },
  { id: 'test', name: 'Testing Agent', icon: TestTube, desc: 'Generates test plans and test cases from scope items.', mode: 'Propose-and-wait' },
  { id: 'mig', name: 'Migration Agent', icon: Database, desc: 'Plans data migrations, field mappings, and validation checklists.', mode: 'Assist' },
  { id: 'config', name: 'Configuration Agent', icon: Settings, desc: 'Creates configuration checklists and detects drift.', mode: 'Assist' },
  { id: 'analysis', name: 'Analysis Agent', icon: BarChart2, desc: 'Cross-engagement analysis, scope creep trends, and lessons synthesis.', mode: 'Auto-execute' },
];

export function Agents() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">AI Agents Console</h1>
        <p className="text-slate-500 mt-1">Manage and trigger your implementation AI agents.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {agents.map((agent) => (
          <div key={agent.id} className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow flex flex-col">
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 rounded-xl bg-indigo-50 flex items-center justify-center text-indigo-600">
                <agent.icon className="w-6 h-6" />
              </div>
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-600 border border-slate-200">
                {agent.mode}
              </span>
            </div>
            <h3 className="text-lg font-semibold text-slate-900 mb-2">{agent.name}</h3>
            <p className="text-sm text-slate-500 mb-6 flex-1">{agent.desc}</p>
            
            <button className="w-full py-2.5 px-4 bg-white border border-slate-300 text-slate-700 rounded-lg text-sm font-medium hover:bg-slate-50 hover:text-indigo-600 hover:border-indigo-200 transition-colors flex items-center justify-center gap-2">
              <Bot className="w-4 h-4" />
              Trigger Agent
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
