import React, { useState, useEffect } from 'react';
import { useAuth } from '../hooks/useAuth';
import { useOrg } from '../hooks/useOrg';
import { supabase } from '../lib/supabase';
import { Building2, Users, CreditCard, User, Loader2, Plus, Mail } from 'lucide-react';
import * as Tabs from '@radix-ui/react-tabs';
import { OrgMember, Profile } from '../types';
import { toast } from 'sonner';

export function Settings() {
  const { user } = useAuth();
  const { organization } = useOrg();
  const [activeTab, setActiveTab] = useState('profile');
  const [loading, setLoading] = useState(true);
  
  // Profile State
  const [fullName, setFullName] = useState('');
  const [isSavingProfile, setIsSavingProfile] = useState(false);

  // Org State
  const [orgName, setOrgName] = useState('');
  const [isSavingOrg, setIsSavingOrg] = useState(false);

  // Team State
  const [members, setMembers] = useState<(OrgMember & { profiles: Profile })[]>([]);
  const [inviteEmail, setInviteEmail] = useState('');
  const [isInviting, setIsInviting] = useState(false);

  // Billing State
  const [isRedirectingToStripe, setIsRedirectingToStripe] = useState(false);

  useEffect(() => {
    async function fetchSettingsData() {
      if (!user || !organization) return;
      
      try {
        // Fetch Profile
        const { data: profileData } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();
          
        if (profileData) {
          setFullName(profileData.full_name || '');
        }

        // Set Org Name
        setOrgName(organization.name);

        // Fetch Team Members
        const { data: membersData } = await supabase
          .from('org_members')
          .select('*, profiles(*)')
          .eq('org_id', organization.id);
          
        if (membersData) {
          setMembers(membersData as any);
        }
      } catch (err) {
        console.error('Error fetching settings data:', err);
      } finally {
        setLoading(false);
      }
    }
    
    fetchSettingsData();
  }, [user, organization]);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    
    setIsSavingProfile(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ full_name: fullName })
        .eq('id', user.id);
        
      if (error) throw error;
      toast.success('Profile updated successfully!');
    } catch (err) {
      console.error('Error saving profile:', err);
      toast.error('Failed to save profile.');
    } finally {
      setIsSavingProfile(false);
    }
  };

  const handleSaveOrg = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!organization) return;
    
    setIsSavingOrg(true);
    try {
      const { error } = await supabase
        .from('organizations')
        .update({ name: orgName })
        .eq('id', organization.id);
        
      if (error) throw error;
      toast.success('Organization updated successfully!');
    } catch (err) {
      console.error('Error saving organization:', err);
      toast.error('Failed to save organization.');
    } finally {
      setIsSavingOrg(false);
    }
  };

  const handleInviteMember = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteEmail.trim() || !organization) return;
    
    setIsInviting(true);
    try {
      // In a real app, this would call an Edge Function to send an invite email
      // and create a pending invite record. For this demo, we'll just show an alert.
      toast.success(`Invite sent to ${inviteEmail}!`);
      setInviteEmail('');
    } catch (err) {
      console.error('Error inviting member:', err);
      toast.error('Failed to invite member.');
    } finally {
      setIsInviting(false);
    }
  };

  const handleManageBilling = async () => {
    setIsRedirectingToStripe(true);
    try {
      const response = await fetch('/api/create-portal-session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ orgId: organization?.id }),
      });
      
      const { url, error } = await response.json();
      if (error) throw new Error(error);
      
      if (url) {
        window.location.href = url;
      } else {
        throw new Error('No URL returned');
      }
    } catch (err: any) {
      console.error('Error redirecting to Stripe:', err);
      toast.error(err.message || 'Failed to open billing portal. Please ensure Stripe is configured.');
      setIsRedirectingToStripe(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-[400px] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Settings</h1>
        <p className="text-slate-500 mt-1">Manage your account, organization, team, and billing.</p>
      </div>

      <Tabs.Root value={activeTab} onValueChange={setActiveTab} className="flex flex-col md:flex-row gap-8">
        <Tabs.List className="flex md:flex-col overflow-x-auto md:overflow-visible border-b md:border-b-0 md:border-r border-slate-200 md:w-64 shrink-0 hide-scrollbar">
          <Tabs.Trigger value="profile" className="flex items-center gap-3 px-4 py-3 text-sm font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-50 data-[state=active]:text-indigo-600 data-[state=active]:bg-indigo-50 data-[state=active]:border-b-2 md:data-[state=active]:border-b-0 md:data-[state=active]:border-r-2 border-indigo-600 transition-colors whitespace-nowrap md:whitespace-normal text-left">
            <User className="w-4 h-4" />
            My Profile
          </Tabs.Trigger>
          <Tabs.Trigger value="organization" className="flex items-center gap-3 px-4 py-3 text-sm font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-50 data-[state=active]:text-indigo-600 data-[state=active]:bg-indigo-50 data-[state=active]:border-b-2 md:data-[state=active]:border-b-0 md:data-[state=active]:border-r-2 border-indigo-600 transition-colors whitespace-nowrap md:whitespace-normal text-left">
            <Building2 className="w-4 h-4" />
            Organization
          </Tabs.Trigger>
          <Tabs.Trigger value="team" className="flex items-center gap-3 px-4 py-3 text-sm font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-50 data-[state=active]:text-indigo-600 data-[state=active]:bg-indigo-50 data-[state=active]:border-b-2 md:data-[state=active]:border-b-0 md:data-[state=active]:border-r-2 border-indigo-600 transition-colors whitespace-nowrap md:whitespace-normal text-left">
            <Users className="w-4 h-4" />
            Team Members
          </Tabs.Trigger>
          <Tabs.Trigger value="billing" className="flex items-center gap-3 px-4 py-3 text-sm font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-50 data-[state=active]:text-indigo-600 data-[state=active]:bg-indigo-50 data-[state=active]:border-b-2 md:data-[state=active]:border-b-0 md:data-[state=active]:border-r-2 border-indigo-600 transition-colors whitespace-nowrap md:whitespace-normal text-left">
            <CreditCard className="w-4 h-4" />
            Billing & Plans
          </Tabs.Trigger>
        </Tabs.List>

        <div className="flex-1 min-w-0">
          <Tabs.Content value="profile" className="focus:outline-none">
            <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-6">
              <h3 className="text-lg font-semibold text-slate-900 mb-6">Profile Settings</h3>
              <form onSubmit={handleSaveProfile} className="space-y-4 max-w-md">
                <div className="space-y-2">
                  <label htmlFor="email" className="text-sm font-medium text-slate-900">Email Address</label>
                  <input
                    id="email"
                    type="email"
                    value={user?.email || ''}
                    disabled
                    className="flex h-10 w-full rounded-md border border-slate-300 bg-slate-50 px-3 py-2 text-sm text-slate-500 cursor-not-allowed"
                  />
                  <p className="text-xs text-slate-500">Your email address cannot be changed.</p>
                </div>
                <div className="space-y-2">
                  <label htmlFor="fullName" className="text-sm font-medium text-slate-900">Full Name</label>
                  <input
                    id="fullName"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="flex h-10 w-full rounded-md border border-slate-300 bg-transparent px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    placeholder="Jane Doe"
                  />
                </div>
                <button
                  type="submit"
                  disabled={isSavingProfile}
                  className="inline-flex items-center justify-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors shadow-sm disabled:opacity-50"
                >
                  {isSavingProfile ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Save Profile'}
                </button>
              </form>
            </div>
          </Tabs.Content>

          <Tabs.Content value="organization" className="focus:outline-none">
            <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-6">
              <h3 className="text-lg font-semibold text-slate-900 mb-6">Organization Settings</h3>
              <form onSubmit={handleSaveOrg} className="space-y-4 max-w-md">
                <div className="space-y-2">
                  <label htmlFor="orgName" className="text-sm font-medium text-slate-900">Organization Name</label>
                  <input
                    id="orgName"
                    value={orgName}
                    onChange={(e) => setOrgName(e.target.value)}
                    className="flex h-10 w-full rounded-md border border-slate-300 bg-transparent px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    required
                  />
                </div>
                <button
                  type="submit"
                  disabled={isSavingOrg}
                  className="inline-flex items-center justify-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors shadow-sm disabled:opacity-50"
                >
                  {isSavingOrg ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Save Organization'}
                </button>
              </form>
            </div>
          </Tabs.Content>

          <Tabs.Content value="team" className="focus:outline-none">
            <div className="space-y-6">
              <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-6">
                <h3 className="text-lg font-semibold text-slate-900 mb-4">Invite Team Member</h3>
                <form onSubmit={handleInviteMember} className="flex gap-3 max-w-md">
                  <div className="flex-1">
                    <label htmlFor="inviteEmail" className="sr-only">Email address</label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input
                        id="inviteEmail"
                        type="email"
                        value={inviteEmail}
                        onChange={(e) => setInviteEmail(e.target.value)}
                        className="flex h-10 w-full rounded-md border border-slate-300 bg-transparent pl-10 pr-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                        placeholder="colleague@company.com"
                        required
                      />
                    </div>
                  </div>
                  <button
                    type="submit"
                    disabled={isInviting || !inviteEmail.trim()}
                    className="inline-flex items-center justify-center gap-2 px-4 py-2 bg-slate-900 text-white rounded-lg text-sm font-medium hover:bg-slate-800 transition-colors shadow-sm disabled:opacity-50"
                  >
                    {isInviting ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Plus className="w-4 h-4" /> Invite</>}
                  </button>
                </form>
              </div>

              <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
                <div className="p-4 border-b border-slate-200 bg-slate-50">
                  <h3 className="font-semibold text-slate-900">Active Members</h3>
                </div>
                <div className="divide-y divide-slate-200">
                  {members.map((member) => (
                    <div key={member.id} className="p-4 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center font-semibold">
                          {member.profiles?.full_name?.charAt(0) || member.profiles?.email?.charAt(0) || '?'}
                        </div>
                        <div>
                          <p className="text-sm font-medium text-slate-900">{member.profiles?.full_name || 'Unknown User'}</p>
                          <p className="text-xs text-slate-500">{member.profiles?.email}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-800 capitalize">
                          {member.role}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </Tabs.Content>

          <Tabs.Content value="billing" className="focus:outline-none">
            <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-6">
              <div className="flex items-start justify-between mb-6">
                <div>
                  <h3 className="text-lg font-semibold text-slate-900">Subscription Plan</h3>
                  <p className="text-slate-500 mt-1">You are currently on the <strong className="text-slate-900">Pro Plan</strong>.</p>
                </div>
                <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-700 border border-green-200">
                  Active
                </span>
              </div>
              
              <div className="bg-slate-50 rounded-lg p-4 border border-slate-200 mb-6">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium text-slate-700">Next billing date</span>
                  <span className="text-sm text-slate-900">May 1, 2026</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium text-slate-700">Amount</span>
                  <span className="text-sm text-slate-900">$49.00 / month</span>
                </div>
              </div>

              <button
                onClick={handleManageBilling}
                disabled={isRedirectingToStripe}
                className="inline-flex items-center justify-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors shadow-sm disabled:opacity-50"
              >
                {isRedirectingToStripe ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Manage Billing & Invoices'}
              </button>
            </div>
          </Tabs.Content>
        </div>
      </Tabs.Root>
    </div>
  );
}
