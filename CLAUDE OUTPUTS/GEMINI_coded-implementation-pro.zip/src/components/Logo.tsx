import React from 'react';
import { cn } from '../lib/utils';

export type LogoProps = React.SVGProps<SVGSVGElement> & {
  variant?: 'full' | 'icon';
  theme?: 'light' | 'dark';
  animated?: boolean;
};

export function Logo({ className, variant = 'full', theme = 'dark', animated = false, ...props }: LogoProps) {
  const textColor = theme === 'dark' ? '#ffffff' : '#0f172a';
  const rectColor = theme === 'dark' ? '#f8fafc' : '#0f172a';
  const circleColor = theme === 'dark' ? '#0f172a' : '#ffffff';

  const innerContent = (
    <>
      <style dangerouslySetInnerHTML={{ __html: `
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap');
        ${animated ? `
          @keyframes pulse-circle {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
          }
          .logo-circle { transform-origin: 60px 50px; animation: pulse-circle 2s ease-in-out infinite; }
        ` : ''}
      `}} />
      <g>
        <rect x="20" y="20" width="16" height="60" rx="4" fill={rectColor} />
        <path d="M44 20 h 16 c 16.5 0 30 13.5 30 30 c 0 16.5 -13.5 30 -30 30 h -16 v -60 z" fill="#2563eb" />
        <circle cx="60" cy="50" r="14" fill={circleColor} className={animated ? "logo-circle" : ""} />
      </g>
    </>
  );

  if (variant === 'icon') {
    return (
      <svg viewBox="0 0 100 100" className={cn("w-auto h-full", className)} xmlns="http://www.w3.org/2000/svg" {...props}>
        {innerContent}
      </svg>
    );
  }

  return (
    <svg viewBox="0 0 550 100" className={cn("w-auto h-full", className)} xmlns="http://www.w3.org/2000/svg" {...props}>
      {innerContent}
      <text x="110" y="64" style={{ fontFamily: '"Space Grotesk", system-ui, sans-serif', fontWeight: 600, letterSpacing: '-0.02em', fill: textColor, fontSize: '42px' }}>
        Implementation Pro
      </text>
    </svg>
  );
}
