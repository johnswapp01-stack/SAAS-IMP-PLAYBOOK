import { GoogleGenAI, Type } from '@google/genai';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function analyzeDocument(file: File) {
  // Convert file to base64
  const base64Data = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const base64 = (reader.result as string).split(',')[1];
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: [
      {
        inlineData: {
          data: base64Data,
          mimeType: file.type,
        }
      },
      "Analyze this project document (SOW, requirements, etc.). Extract the scope items (using MoSCoW prioritization), key stakeholders, and potential risks."
    ],
    config: {
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          scopeItems: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                priority: { type: Type.STRING, description: "Must Have, Should Have, Could Have, or Won't Have" },
              },
              required: ['title', 'priority']
            }
          },
          stakeholders: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                role: { type: Type.STRING },
                email: { type: Type.STRING },
              },
              required: ['name', 'role']
            }
          },
          risks: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                description: { type: Type.STRING },
                severity: { type: Type.STRING, description: "low, medium, high, or critical" },
                type: { type: Type.STRING, description: "timeline, scope, budget, stakeholder, technical, or resource" }
              },
              required: ['description', 'severity', 'type']
            }
          }
        },
        required: ['scopeItems', 'stakeholders', 'risks']
      },
    }
  });

  if (!response.text) {
    throw new Error("Failed to generate content");
  }

  return JSON.parse(response.text);
}
