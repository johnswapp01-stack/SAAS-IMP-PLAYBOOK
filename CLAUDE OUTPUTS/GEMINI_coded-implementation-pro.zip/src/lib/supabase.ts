import { createClient } from '@supabase/supabase-js';

const supabaseUrl = (import.meta as any).env.VITE_SUPABASE_URL || 'https://placeholder-project.supabase.co';
const supabaseAnonKey = (import.meta as any).env.VITE_SUPABASE_ANON_KEY || 'placeholder-key';

// Initialize the Supabase client
// This client is ready to be used with your Supabase Vector DB (pgvector)
export const supabase = createClient(supabaseUrl, supabaseAnonKey);
