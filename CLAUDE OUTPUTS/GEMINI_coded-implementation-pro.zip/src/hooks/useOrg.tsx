import React, { useState, useEffect, createContext, useContext } from 'react';
import { supabase } from '../lib/supabase';
import { Organization, OrgMember } from '../types';
import { useAuth } from './useAuth';

type OrgContextType = {
  organization: Organization | null;
  memberRole: OrgMember['role'] | null;
  loading: boolean;
  refreshOrg: () => Promise<void>;
};

const OrgContext = createContext<OrgContextType>({
  organization: null,
  memberRole: null,
  loading: true,
  refreshOrg: async () => {},
});

export function OrgProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const [organization, setOrganization] = useState<Organization | null>(null);
  const [memberRole, setMemberRole] = useState<OrgMember['role'] | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchOrg = async () => {
    if (!user) {
      setOrganization(null);
      setMemberRole(null);
      setLoading(false);
      return;
    }

    try {
      // Get the user's org membership
      const { data: memberData, error: memberError } = await supabase
        .from('org_members')
        .select('org_id, role')
        .eq('user_id', user.id)
        .single();

      if (memberError || !memberData) {
        setOrganization(null);
        setMemberRole(null);
        setLoading(false);
        return;
      }

      // Get the org details
      const { data: orgData, error: orgError } = await supabase
        .from('organizations')
        .select('*')
        .eq('id', memberData.org_id)
        .single();

      if (orgError) {
        console.error('Error fetching org:', orgError);
      } else {
        setOrganization(orgData);
        setMemberRole(memberData.role);
      }
    } catch (err) {
      console.error('Failed to fetch org:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrg();
  }, [user]);

  return (
    <OrgContext.Provider value={{ organization, memberRole, loading, refreshOrg: fetchOrg }}>
      {children}
    </OrgContext.Provider>
  );
}

export const useOrg = () => useContext(OrgContext);
