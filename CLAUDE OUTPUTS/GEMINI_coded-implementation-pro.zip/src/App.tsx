/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { StrictMode } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ErrorBoundary } from 'react-error-boundary';
import { Toaster } from 'sonner';
import { DashboardLayout } from './components/layout/DashboardLayout';
import { Dashboard } from './pages/Dashboard';
import { Engagements } from './pages/Engagements';
import { NewEngagement } from './pages/NewEngagement';
import { EngagementDetail } from './pages/EngagementDetail';
import { Agents } from './pages/Agents';
import { Settings } from './pages/Settings';
import { Login } from './pages/Login';
import { Onboarding } from './pages/Onboarding';
import { AuthProvider, useAuth } from './hooks/useAuth';
import { OrgProvider, useOrg } from './hooks/useOrg';
import { ProtectedRoute } from './components/ProtectedRoute';

function ErrorFallback({ error, resetErrorBoundary }: { error: Error, resetErrorBoundary: () => void }) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
      <div className="bg-white p-8 rounded-xl shadow-sm border border-slate-200 max-w-md w-full text-center">
        <h2 className="text-xl font-bold text-slate-900 mb-2">Something went wrong</h2>
        <p className="text-sm text-slate-500 mb-6 font-mono bg-slate-50 p-2 rounded text-left overflow-auto max-h-32">
          {error.message}
        </p>
        <button
          onClick={resetErrorBoundary}
          className="px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors"
        >
          Try again
        </button>
      </div>
    </div>
  );
}

// Helper component to redirect authenticated users away from login
function PublicRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) return null;
  if (user) return <Navigate to="/" replace />;
  return <>{children}</>;
}

// Helper component to redirect users with orgs away from onboarding
function OnboardingRoute({ children }: { children: React.ReactNode }) {
  const { user, loading: authLoading } = useAuth();
  const { organization, loading: orgLoading } = useOrg();
  
  if (authLoading || orgLoading) return null;
  if (!user) return <Navigate to="/login" replace />;
  if (organization) return <Navigate to="/" replace />;
  
  return <>{children}</>;
}

export default function App() {
  return (
    <ErrorBoundary FallbackComponent={ErrorFallback}>
      <AuthProvider>
        <OrgProvider>
          <BrowserRouter>
            <Toaster position="top-right" richColors />
            <Routes>
              <Route path="/login" element={<PublicRoute><Login /></PublicRoute>} />
              <Route path="/onboarding" element={<OnboardingRoute><Onboarding /></OnboardingRoute>} />
              
              <Route path="/" element={<ProtectedRoute />}>
                <Route element={<DashboardLayout />}>
                  <Route index element={<Dashboard />} />
                  <Route path="engagements" element={<Engagements />} />
                  <Route path="engagements/new" element={<NewEngagement />} />
                  <Route path="engagements/:id" element={<EngagementDetail />} />
                  <Route path="agents" element={<Agents />} />
                  <Route path="settings" element={<Settings />} />
                </Route>
              </Route>
            </Routes>
          </BrowserRouter>
        </OrgProvider>
      </AuthProvider>
    </ErrorBoundary>
  );
}
