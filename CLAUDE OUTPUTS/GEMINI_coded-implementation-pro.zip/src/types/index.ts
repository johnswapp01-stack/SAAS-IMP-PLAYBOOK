export type Organization = {
  id: string;
  name: string;
  slug: string;
  created_at: string;
};

export type Profile = {
  id: string;
  email: string;
  full_name: string | null;
  avatar_url: string | null;
  created_at: string;
};

export type OrgMember = {
  id: string;
  org_id: string;
  user_id: string;
  role: 'owner' | 'admin' | 'member' | 'viewer';
  created_at: string;
};

export type Engagement = {
  id: string;
  org_id: string;
  name: string;
  client_name: string;
  status: 'kickoff' | 'in_progress' | 'uat' | 'go_live' | 'complete';
  health: 'green' | 'yellow' | 'red';
  health_score: number;
  progress: number;
  manager_id: string | null;
  created_at: string;
  updated_at: string;
};

export type ScopeItem = {
  id: string;
  engagement_id: string;
  title: string;
  description: string | null;
  priority: 'Must Have' | 'Should Have' | 'Could Have' | 'Won\'t Have';
  status: 'Not Started' | 'In Progress' | 'Completed' | 'Blocked';
  created_at: string;
  updated_at: string;
};

export type Stakeholder = {
  id: string;
  engagement_id: string;
  name: string;
  role: string;
  email: string | null;
  influence: 'High' | 'Medium' | 'Low';
  communication_preference: string | null;
  created_at: string;
  updated_at: string;
};

export type RaciItem = {
  id: string;
  engagement_id: string;
  task: string;
  responsible: string | null;
  accountable: string | null;
  consulted: string | null;
  informed: string | null;
  created_at: string;
  updated_at: string;
};

export type ChecklistItem = {
  id: string;
  engagement_id: string;
  category: 'kickoff' | 'go_live';
  task: string;
  status: 'pending' | 'completed' | 'n_a';
  owner: string | null;
  sign_off: string | null;
  created_at: string;
  updated_at: string;
};

export type RiskSignal = {
  id: string;
  engagement_id: string;
  type: 'timeline' | 'scope' | 'budget' | 'stakeholder' | 'technical' | 'resource';
  description: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  confidence: number;
  status: 'open' | 'mitigated' | 'realized';
  created_at: string;
  updated_at: string;
};

export type StatusReport = {
  id: string;
  engagement_id: string;
  type: 'internal' | 'customer' | 'executive';
  report_date: string;
  content: string;
  status: 'draft' | 'approved' | 'sent';
  created_at: string;
  updated_at: string;
};
