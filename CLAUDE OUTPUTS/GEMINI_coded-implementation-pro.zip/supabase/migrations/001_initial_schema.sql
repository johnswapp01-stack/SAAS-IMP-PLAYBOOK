-- 001_initial_schema.sql
-- Baseline schema for Implementation Pro

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Profiles
CREATE TABLE profiles (
  id UUID REFERENCES auth.users(id) PRIMARY KEY,
  email TEXT NOT NULL,
  full_name TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Organizations
CREATE TABLE organizations (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Org Members
CREATE TABLE org_members (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  org_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  role TEXT CHECK (role IN ('owner', 'admin', 'member', 'viewer')) DEFAULT 'member',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(org_id, user_id)
);

-- Engagements
CREATE TABLE engagements (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  org_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  client_name TEXT NOT NULL,
  status TEXT CHECK (status IN ('kickoff', 'in_progress', 'uat', 'go_live', 'complete')) DEFAULT 'kickoff',
  health TEXT CHECK (health IN ('green', 'yellow', 'red')) DEFAULT 'green',
  health_score INTEGER DEFAULT 100,
  progress INTEGER DEFAULT 0,
  manager_id UUID REFERENCES profiles(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Scope Items
CREATE TABLE scope_items (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  engagement_id UUID REFERENCES engagements(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  priority TEXT CHECK (priority IN ('Must Have', 'Should Have', 'Could Have', 'Won''t Have')),
  status TEXT CHECK (status IN ('Not Started', 'In Progress', 'Completed', 'Blocked')) DEFAULT 'Not Started',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Stakeholders
CREATE TABLE stakeholders (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  engagement_id UUID REFERENCES engagements(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  role TEXT NOT NULL,
  email TEXT,
  influence TEXT CHECK (influence IN ('High', 'Medium', 'Low')),
  communication_preference TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- RACI Items
CREATE TABLE raci_items (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  engagement_id UUID REFERENCES engagements(id) ON DELETE CASCADE,
  task TEXT NOT NULL,
  responsible TEXT,
  accountable TEXT,
  consulted TEXT,
  informed TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Checklist Items
CREATE TABLE checklist_items (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  engagement_id UUID REFERENCES engagements(id) ON DELETE CASCADE,
  category TEXT CHECK (category IN ('kickoff', 'go_live')),
  task TEXT NOT NULL,
  status TEXT CHECK (status IN ('pending', 'completed', 'n_a')) DEFAULT 'pending',
  owner TEXT,
  sign_off TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Risk Signals
CREATE TABLE risk_signals (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  engagement_id UUID REFERENCES engagements(id) ON DELETE CASCADE,
  type TEXT CHECK (type IN ('timeline', 'scope', 'budget', 'stakeholder', 'technical', 'resource')),
  description TEXT NOT NULL,
  severity TEXT CHECK (severity IN ('low', 'medium', 'high', 'critical')),
  confidence INTEGER,
  status TEXT CHECK (status IN ('open', 'mitigated', 'realized')) DEFAULT 'open',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Status Reports
CREATE TABLE status_reports (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  engagement_id UUID REFERENCES engagements(id) ON DELETE CASCADE,
  type TEXT CHECK (type IN ('internal', 'customer', 'executive')),
  report_date TIMESTAMPTZ NOT NULL,
  content TEXT NOT NULL,
  status TEXT CHECK (status IN ('draft', 'approved', 'sent')) DEFAULT 'draft',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- RLS Policies (Simplified for brevity)
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE org_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE engagements ENABLE ROW LEVEL SECURITY;
ALTER TABLE scope_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE stakeholders ENABLE ROW LEVEL SECURITY;
ALTER TABLE raci_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE checklist_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE risk_signals ENABLE ROW LEVEL SECURITY;
ALTER TABLE status_reports ENABLE ROW LEVEL SECURITY;

-- Helper function
CREATE OR REPLACE FUNCTION is_org_member(org_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM org_members
    WHERE org_members.org_id = $1
    AND org_members.user_id = auth.uid()
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Example Policy
CREATE POLICY "Users can view their orgs" ON organizations
  FOR SELECT USING (
    id IN (SELECT org_id FROM org_members WHERE user_id = auth.uid())
  );
