/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Check, Copy, Download, LayoutTemplate, Type, Palette, 
  Share2, Moon, Sun, Archive, Loader2, Smartphone, 
  Menu, X, ChevronRight, Zap, Shield, Rocket
} from 'lucide-react';
import JSZip from 'jszip';
import { renderToStaticMarkup } from 'react-dom/server';

// --- Data & SVG Generation ---

const CONCEPTS = [
  {
    id: 'monogram',
    name: 'The Monogram',
    description: 'A strong, authoritative "IP" mark that conveys stability, structure, and professional expertise.',
    fontFamily: '"Space Grotesk", system-ui, sans-serif',
    fontWeight: 600,
    letterSpacing: '-0.02em',
    fontClass: 'font-display tracking-tight',
    colors: [
      { name: 'Primary Blue', hex: '#2563eb', class: 'bg-blue-600' },
      { name: 'Slate Dark', hex: '#1e293b', class: 'bg-slate-800' },
      { name: 'Slate Light', hex: '#f8fafc', class: 'bg-slate-50' },
    ]
  },
  {
    id: 'catalyst',
    name: 'The Catalyst',
    description: 'Forward-pointing chevrons representing efficiency, progress, and moving projects to completion.',
    fontFamily: '"Inter", system-ui, sans-serif',
    fontWeight: 600,
    letterSpacing: '-0.02em',
    fontClass: 'font-sans font-semibold tracking-tight',
    colors: [
      { name: 'Action Blue', hex: '#2563eb', class: 'bg-blue-600' },
      { name: 'Deep Navy', hex: '#0f172a', class: 'bg-slate-900' },
      { name: 'Pure White', hex: '#ffffff', class: 'bg-white' },
    ]
  },
  {
    id: 'integrator',
    name: 'The Integrator',
    description: 'Interlocking geometric shapes symbolizing seamless integration, systems coming together, and solid foundations.',
    fontFamily: '"Inter", system-ui, sans-serif',
    fontWeight: 700,
    letterSpacing: '-0.05em',
    fontClass: 'font-sans font-bold tracking-tighter',
    colors: [
      { name: 'Tech Blue', hex: '#2563eb', class: 'bg-blue-600' },
      { name: 'Charcoal', hex: '#1e293b', class: 'bg-slate-800' },
      { name: 'Cloud', hex: '#f1f5f9', class: 'bg-slate-100' },
    ]
  }
];

const getElements = (theme: 'light' | 'dark', id: string, isAnimated: boolean = false) => {
  const isDark = theme === 'dark';
  if (id === 'monogram') {
    const primary = '#2563eb';
    const dark = isDark ? '#f8fafc' : '#1e293b';
    const bg = isDark ? '#0f172a' : '#ffffff';
    return (
      <>
        <rect x="20" y="20" width="16" height="60" rx="4" fill={dark} style={isAnimated ? { animation: 'fadeUp 0.8s ease-out forwards' } : {}} />
        <path d="M44 20 h 16 c 16.5 0 30 13.5 30 30 c 0 16.5 -13.5 30 -30 30 h -16 v -60 z" fill={primary} style={isAnimated ? { animation: 'fadeLeft 0.8s ease-out 0.2s both' } : {}} />
        <circle cx="60" cy="50" r="14" fill={bg} style={isAnimated ? { animation: 'fadeDown 0.6s ease-out 0.5s both' } : {}} />
      </>
    );
  }
  if (id === 'catalyst') {
    const primary = '#2563eb';
    const dark = isDark ? '#f8fafc' : '#0f172a';
    return (
      <>
        <path d="M24 24 L54 50 L24 76" stroke={primary} strokeWidth="14" strokeLinecap="round" strokeLinejoin="round" fill="none" style={isAnimated ? { animation: 'slideRight 2s ease-in-out infinite' } : {}} />
        <path d="M54 24 L84 50 L54 76" stroke={dark} strokeWidth="14" strokeLinecap="round" strokeLinejoin="round" fill="none" style={isAnimated ? { animation: 'slideRight 2s ease-in-out infinite 0.2s' } : {}} />
      </>
    );
  }
  if (id === 'integrator') {
    const primary = '#2563eb';
    const dark = isDark ? '#f8fafc' : '#1e293b';
    const bg = isDark ? '#0f172a' : '#ffffff';
    return (
      <>
        <rect x="15" y="25" width="45" height="45" rx="10" fill={primary} opacity="0.9" style={isAnimated ? { animation: 'assembleLeft 1s ease-out forwards' } : {}} />
        <rect x="40" y="35" width="45" height="45" rx="10" fill={dark} opacity="0.9" style={isAnimated ? { animation: 'assembleRight 1s ease-out forwards' } : {}} />
        <rect x="40" y="35" width="20" height="20" rx="6" fill={bg} style={isAnimated ? { animation: 'fadeIn 0.6s ease-out 0.8s both' } : {}} />
      </>
    );
  }
  return null;
};

const LogoRenderer = ({ concept, layout, theme, id, isAnimated = false }: { concept: any, layout: string, theme: 'light' | 'dark', id: string, isAnimated?: boolean }) => {
  const isDark = theme === 'dark';
  const textColor = isDark ? '#ffffff' : '#0f172a';
  const elements = getElements(theme, concept.id, isAnimated);

  let viewBox = "0 0 100 100";
  let content = null;

  const textStyle = {
    fontFamily: concept.fontFamily,
    fontWeight: concept.fontWeight,
    letterSpacing: concept.letterSpacing,
    fill: textColor,
  };

  const animationStyles = isAnimated ? `
    @keyframes fadeUp { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes fadeLeft { from { opacity: 0; transform: translateX(-10px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes fadeDown { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slideRight { 0%, 100% { transform: translateX(0); } 50% { transform: translateX(6px); } }
    @keyframes assembleLeft { from { transform: translateX(-15px); opacity: 0; } to { transform: translateX(0); opacity: 0.9; } }
    @keyframes assembleRight { from { transform: translateX(15px); opacity: 0; } to { transform: translateX(0); opacity: 0.9; } }
    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
  ` : '';

  if (layout === 'icon') {
    viewBox = "0 0 100 100";
    content = elements;
  } else if (layout === 'horizontal') {
    viewBox = "0 0 550 100";
    content = (
      <>
        <g>{elements}</g>
        <text x="110" y="64" style={{...textStyle, fontSize: '42px'}}>Implementation Pro</text>
      </>
    );
  } else if (layout === 'stacked') {
    viewBox = "0 0 400 260";
    content = (
      <>
        <g transform="translate(150, 20)">{elements}</g>
        <text x="200" y="170" textAnchor="middle" style={{...textStyle, fontSize: '42px'}}>Implementation</text>
        <text x="200" y="220" textAnchor="middle" style={{...textStyle, fontSize: '42px'}}>Pro</text>
      </>
    );
  } else if (layout === 'wordmark') {
    viewBox = "0 0 450 100";
    content = (
      <text x="225" y="64" textAnchor="middle" style={{...textStyle, fontSize: '46px'}}>Implementation Pro</text>
    );
  } else if (layout === 'badge') {
    viewBox = "0 0 300 300";
    content = (
      <>
        <circle cx="150" cy="150" r="140" fill="none" stroke={textColor} strokeWidth="2" opacity="0.1" />
        <circle cx="150" cy="150" r="125" fill="none" stroke={textColor} strokeWidth="1" strokeDasharray="4 4" opacity="0.3" />
        <g transform="translate(100, 55) scale(1)">{elements}</g>
        <text x="150" y="205" textAnchor="middle" style={{...textStyle, fontSize: '20px', letterSpacing: '0.15em'}}>IMPLEMENTATION</text>
        <text x="150" y="235" textAnchor="middle" style={{...textStyle, fontSize: '20px', letterSpacing: '0.15em'}}>PRO</text>
      </>
    );
  } else if (layout === 'compact') {
    viewBox = "0 0 300 160";
    content = (
      <>
        <g transform="translate(100, 10) scale(1)">{elements}</g>
        <text x="150" y="145" textAnchor="middle" style={{...textStyle, fontSize: '26px'}}>Implementation Pro</text>
      </>
    );
  }

  return (
    <svg id={id} viewBox={viewBox} className="w-full h-full max-h-full" xmlns="http://www.w3.org/2000/svg">
      <style>
        {`@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap');
          ${animationStyles}
        `}
      </style>
      {content}
    </svg>
  );
};

const downloadSvg = (id: string, filename: string) => {
  const svgElement = document.getElementById(id);
  if (!svgElement) return;

  const serializer = new XMLSerializer();
  let source = serializer.serializeToString(svgElement);

  if(!source.match(/^<svg[^>]+xmlns="http\:\/\/www\.w3\.org\/2000\/svg"/)){
      source = source.replace(/^<svg/, '<svg xmlns="http://www.w3.org/2000/svg"');
  }

  source = '<?xml version="1.0" standalone="no"?>\r\n' + source;
  const url = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(source);

  const downloadLink = document.createElement("a");
  downloadLink.href = url;
  downloadLink.download = filename + ".svg";
  document.body.appendChild(downloadLink);
  downloadLink.click();
  document.body.removeChild(downloadLink);
};

// --- Components ---

const LogoCard = ({ title, concept, layout, theme, id, className = "", isAnimated = false }: any) => {
  const isDark = theme === 'dark';
  return (
    <div className={`rounded-2xl border p-8 flex flex-col items-center justify-center relative group transition-colors ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'} ${className}`}>
      <div className={`absolute top-4 left-4 text-xs font-medium uppercase tracking-wider ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>
        {title}
      </div>
      <button
        onClick={() => downloadSvg(id, `${concept.id}-${layout}-${theme}${isAnimated ? '-animated' : ''}`)}
        className={`absolute top-4 right-4 px-3 py-2 rounded-lg opacity-0 group-hover:opacity-100 transition-all flex items-center gap-2 text-sm font-medium shadow-sm ${isDark ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700' : 'bg-white hover:bg-slate-50 text-slate-700 border border-slate-200'}`}
        title="Download SVG"
      >
        <Download className="w-4 h-4" />
        <span className="hidden sm:inline">SVG</span>
      </button>
      <div className="w-full h-32 flex items-center justify-center mt-4">
         <LogoRenderer id={id} concept={concept} layout={layout} theme={theme} isAnimated={isAnimated} />
      </div>
    </div>
  );
};

const SocialAssetRenderer = ({ concept, type, id }: { concept: any, type: string, id: string }) => {
  let viewBox = "0 0 1080 1080";
  let content = null;
  const isDark = type !== 'banner-linkedin';
  const theme = isDark ? 'dark' : 'light';
  
  const darkColor = concept.colors[1].hex;
  const lightColor = concept.colors[2].hex;
  
  const bgColor = isDark ? darkColor : lightColor;
  const textColor = isDark ? '#ffffff' : darkColor;

  const textStyle = {
    fontFamily: concept.fontFamily,
    fontWeight: concept.fontWeight,
    letterSpacing: concept.letterSpacing,
    fill: textColor,
  };

  if (type === 'profile') {
    viewBox = "0 0 1080 1080";
    content = (
      <>
        <rect width="1080" height="1080" fill={bgColor} />
        <g transform="translate(290, 290) scale(5)">
          {getElements(theme, concept.id)}
        </g>
      </>
    );
  } else if (type === 'banner-twitter') {
    viewBox = "0 0 1500 500";
    content = (
      <>
        <rect width="1500" height="500" fill={bgColor} />
        <g transform="translate(1100, -150) scale(8)" opacity="0.05">
           {getElements(theme, concept.id)}
        </g>
        <g transform="translate(150, 175) scale(1.5)">
          {getElements(theme, concept.id)}
        </g>
        <text x="330" y="255" style={{...textStyle, fontSize: '64px'}}>Implementation Pro</text>
        <text x="335" y="310" style={{fontFamily: '"Inter", sans-serif', fontWeight: 400, fill: textColor, opacity: 0.7, fontSize: '24px'}}>Professional Implementation Services</text>
      </>
    );
  } else if (type === 'banner-linkedin') {
    viewBox = "0 0 1584 396";
    content = (
      <>
        <rect width="1584" height="396" fill={bgColor} />
        <g transform="translate(1200, -100) scale(6)" opacity="0.05">
           {getElements(theme, concept.id)}
        </g>
        <g transform="translate(120, 123) scale(1.5)">
          {getElements(theme, concept.id)}
        </g>
        <text x="300" y="203" style={{...textStyle, fontSize: '56px'}}>Implementation Pro</text>
        <text x="305" y="250" style={{fontFamily: '"Inter", sans-serif', fontWeight: 400, fill: textColor, opacity: 0.7, fontSize: '22px'}}>Professional Implementation Services</text>
      </>
    );
  }

  return (
    <svg id={id} viewBox={viewBox} className="w-full h-full object-cover" xmlns="http://www.w3.org/2000/svg">
      <style>
        {`@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap');`}
      </style>
      {content}
    </svg>
  );
};

const SocialAssetCard = ({ title, dimensions, concept, type, id, aspectClass = "", className = "" }: any) => {
  return (
    <div className={`rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 flex flex-col relative group transition-colors ${className}`}>
      <div className="flex justify-between items-start mb-4">
        <div>
          <div className="text-sm font-semibold text-slate-900 dark:text-white">{title}</div>
          <div className="text-xs text-slate-500 dark:text-slate-400">{dimensions}</div>
        </div>
        <button
          onClick={() => downloadSvg(id, `${concept.id}-${type}`)}
          className="px-3 py-2 rounded-lg opacity-0 group-hover:opacity-100 transition-all flex items-center gap-2 text-sm font-medium shadow-sm bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700"
          title="Download SVG"
        >
          <Download className="w-4 h-4" />
          <span className="hidden sm:inline">SVG</span>
        </button>
      </div>
      <div className={`w-full bg-slate-100 dark:bg-slate-950 rounded-lg overflow-hidden border border-slate-200 dark:border-slate-800 flex items-center justify-center transition-colors ${aspectClass}`}>
         <SocialAssetRenderer id={id} concept={concept} type={type} />
      </div>
    </div>
  );
};

const ColorSwatch = ({ color }: any) => {
  const [copied, setCopied] = useState(false);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(color.hex);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex flex-col gap-2 group">
      <div 
        className={`h-24 w-full rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm relative cursor-pointer transition-transform hover:scale-105 ${color.class}`}
        onClick={copyToClipboard}
      >
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/20 rounded-xl">
          {copied ? <Check className="text-white w-6 h-6" /> : <Copy className="text-white w-6 h-6" />}
        </div>
      </div>
      <div>
        <div className="text-sm font-medium text-slate-900 dark:text-white">{color.name}</div>
        <div className="text-xs text-slate-500 dark:text-slate-400 font-mono uppercase">{color.hex}</div>
      </div>
    </div>
  );
};

const MobileMockup = ({ concept, theme }: { concept: any, theme: 'light' | 'dark' }) => {
  const isDark = theme === 'dark';
  const primaryColor = concept.colors[0].hex;
  
  return (
    <div className="relative mx-auto border-slate-800 dark:border-slate-700 bg-slate-800 dark:bg-slate-700 border-[14px] rounded-[2.5rem] h-[500px] w-[250px] shadow-xl overflow-hidden">
      <div className="w-[120px] h-[18px] bg-slate-800 dark:bg-slate-700 top-0 left-1/2 -translate-x-1/2 absolute rounded-b-xl z-20"></div>
      <div className="h-[46px] w-[3px] bg-slate-800 dark:bg-slate-700 absolute -left-[17px] top-[124px] rounded-l-lg"></div>
      <div className="h-[46px] w-[3px] bg-slate-800 dark:bg-slate-700 absolute -left-[17px] top-[178px] rounded-l-lg"></div>
      <div className="h-[64px] w-[3px] bg-slate-800 dark:bg-slate-700 absolute -right-[17px] top-[142px] rounded-r-lg"></div>
      
      <div className={`h-full w-full rounded-[2rem] overflow-hidden flex flex-col ${isDark ? 'bg-slate-950' : 'bg-slate-50'}`}>
        {/* App Header */}
        <div className={`px-4 pt-8 pb-4 flex items-center justify-between ${isDark ? 'bg-slate-900' : 'bg-white shadow-sm'}`}>
          <div className="w-6 h-6">
            <LogoRenderer concept={concept} layout="icon" theme={theme} id="mockup-logo" />
          </div>
          <div className={`w-8 h-2 rounded-full ${isDark ? 'bg-slate-800' : 'bg-slate-100'}`}></div>
        </div>
        
        {/* App Content */}
        <div className="p-4 space-y-4 flex-1">
          <div className={`h-24 rounded-xl flex items-center justify-center ${isDark ? 'bg-slate-900' : 'bg-white shadow-sm'}`}>
             <div className="w-12 h-12 opacity-20">
               <LogoRenderer concept={concept} layout="icon" theme={theme} id="mockup-bg" />
             </div>
          </div>
          <div className="space-y-2">
            <div className={`h-3 w-3/4 rounded-full ${isDark ? 'bg-slate-800' : 'bg-slate-200'}`}></div>
            <div className={`h-3 w-1/2 rounded-full ${isDark ? 'bg-slate-800' : 'bg-slate-200'}`}></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className={`h-20 rounded-xl ${isDark ? 'bg-slate-900' : 'bg-white shadow-sm'}`}></div>
            <div className={`h-20 rounded-xl ${isDark ? 'bg-slate-900' : 'bg-white shadow-sm'}`}></div>
          </div>
          <div className={`h-32 rounded-xl border-2 border-dashed ${isDark ? 'border-slate-800' : 'border-slate-200'}`}></div>
        </div>
        
        {/* App Bottom Nav */}
        <div className={`h-16 flex items-center justify-around px-4 border-t ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'}`}>
          <div className="w-6 h-6 rounded-full bg-blue-600"></div>
          <div className={`w-6 h-6 rounded-full ${isDark ? 'bg-slate-800' : 'bg-slate-100'}`}></div>
          <div className={`w-6 h-6 rounded-full ${isDark ? 'bg-slate-800' : 'bg-slate-100'}`}></div>
          <div className={`w-6 h-6 rounded-full ${isDark ? 'bg-slate-800' : 'bg-slate-100'}`}></div>
        </div>
      </div>
    </div>
  );
};

export default function App() {
  const [activeConcept, setActiveConcept] = useState(0);
  const [isAnimated, setIsAnimated] = useState(false);
  const [appTheme, setAppTheme] = useState<'light' | 'dark'>('light');
  const [isGeneratingZip, setIsGeneratingZip] = useState(false);
  const [activeTab, setActiveTab] = useState('logos');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  
  const concept = CONCEPTS[activeConcept];

  // Persist theme
  useEffect(() => {
    const savedTheme = localStorage.getItem('brand-kit-theme');
    if (savedTheme === 'dark' || savedTheme === 'light') {
      setAppTheme(savedTheme);
    }
  }, []);

  const toggleTheme = () => {
    const newTheme = appTheme === 'light' ? 'dark' : 'light';
    setAppTheme(newTheme);
    localStorage.setItem('brand-kit-theme', newTheme);
  };

  const handleDownloadZip = async () => {
    setIsGeneratingZip(true);
    try {
      const zip = new JSZip();
      const logosFolder = zip.folder("Logos");
      const socialFolder = zip.folder("Social Media");

      const addSvg = (folder: any, filename: string, component: React.ReactElement) => {
        let svgString = renderToStaticMarkup(component);
        if(!svgString.match(/^<svg[^>]+xmlns="http\:\/\/www\.w3\.org\/2000\/svg"/)){
            svgString = svgString.replace(/^<svg/, '<svg xmlns="http://www.w3.org/2000/svg"');
        }
        svgString = '<?xml version="1.0" standalone="no"?>\r\n' + svgString;
        folder?.file(`${filename}.svg`, svgString);
      };

      // Logos
      const layouts = ['horizontal', 'stacked', 'icon', 'wordmark', 'badge', 'compact'];
      const themes = ['light', 'dark'];
      
      layouts.forEach(layout => {
        themes.forEach(theme => {
          addSvg(
            logosFolder, 
            `${concept.id}-${layout}-${theme}${isAnimated ? '-animated' : ''}`, 
            <LogoRenderer concept={concept} layout={layout} theme={theme as any} id={`export-${layout}-${theme}`} isAnimated={isAnimated} />
          );
        });
      });

      // Social Media
      const socialTypes = ['profile', 'banner-twitter', 'banner-linkedin'];
      socialTypes.forEach(type => {
        addSvg(
          socialFolder,
          `${concept.id}-${type}`,
          <SocialAssetRenderer concept={concept} type={type} id={`export-${type}`} />
        );
      });

      const content = await zip.generateAsync({ type: "blob" });
      const url = URL.createObjectURL(content);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${concept.id}-brand-kit.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Failed to generate zip", error);
    } finally {
      setIsGeneratingZip(false);
    }
  };

  const navItems = [
    { id: 'logos', label: 'Logos', icon: LayoutTemplate },
    { id: 'social', label: 'Social', icon: Share2 },
    { id: 'colors', label: 'Colors', icon: Palette },
    { id: 'typography', label: 'Type', icon: Type },
    { id: 'mobile', label: 'Mobile-First', icon: Smartphone },
  ];

  return (
    <div className={appTheme === 'dark' ? 'dark' : ''}>
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 pb-24 lg:pb-0 lg:pl-64 transition-colors duration-200">
        
        {/* Desktop Sidebar */}
        <aside className="hidden lg:flex flex-col fixed inset-y-0 left-0 w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 z-30 transition-colors">
          <div className="p-6 flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20">
              <Palette className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-sm font-bold text-slate-900 dark:text-white leading-tight">Brand Kit</h1>
              <p className="text-[10px] font-medium text-slate-500 uppercase tracking-widest">Implementation Pro</p>
            </div>
          </div>

          <nav className="flex-1 px-4 py-4 space-y-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                  activeTab === item.id
                    ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                <item.icon className="w-5 h-5" />
                {item.label}
              </button>
            ))}
          </nav>

          <div className="p-4 border-t border-slate-200 dark:border-slate-800">
            <button
              onClick={toggleTheme}
              className="w-full flex items-center justify-between px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
            >
              <span className="text-sm font-medium">Theme</span>
              {appTheme === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
            </button>
          </div>
        </aside>

        {/* Mobile Header */}
        <header className="lg:hidden bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 sticky top-0 z-30 transition-colors">
          <div className="px-4 h-16 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Palette className="w-5 h-5 text-blue-600" />
              <span className="font-bold text-slate-900 dark:text-white">Brand Kit</span>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={toggleTheme} className="p-2 rounded-lg text-slate-500 dark:text-slate-400">
                {appTheme === 'light' ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
              </button>
              <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="p-2 rounded-lg text-slate-500 dark:text-slate-400">
                {isSidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
          
          {/* Mobile Sidebar Overlay */}
          <AnimatePresence>
            {isSidebarOpen && (
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="absolute top-16 inset-x-0 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 shadow-xl p-4 space-y-2 z-40"
              >
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-4 mb-2">Select Concept</div>
                <div className="flex flex-wrap gap-2 px-2 pb-4">
                  {CONCEPTS.map((c, idx) => (
                    <button
                      key={c.id}
                      onClick={() => { setActiveConcept(idx); setIsSidebarOpen(false); }}
                      className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                        activeConcept === idx 
                          ? 'bg-blue-600 text-white' 
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      {c.name}
                    </button>
                  ))}
                </div>
                <div className="border-t border-slate-100 dark:border-slate-800 pt-4">
                  <button
                    onClick={handleDownloadZip}
                    disabled={isGeneratingZip}
                    className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-blue-600 text-white rounded-xl font-bold text-sm"
                  >
                    {isGeneratingZip ? <Loader2 className="w-4 h-4 animate-spin" /> : <Archive className="w-4 h-4" />}
                    Download {concept.name} Kit
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </header>

        {/* Desktop Concept Switcher (Top Bar) */}
        <div className="hidden lg:flex items-center justify-between px-8 py-4 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 sticky top-0 z-20">
          <div className="flex items-center gap-4">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Current Concept:</span>
            <div className="flex gap-2">
              {CONCEPTS.map((c, idx) => (
                <button
                  key={c.id}
                  onClick={() => setActiveConcept(idx)}
                  className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all ${
                    activeConcept === idx 
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20' 
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  {c.name}
                </button>
              ))}
            </div>
          </div>
          <button
            onClick={handleDownloadZip}
            disabled={isGeneratingZip}
            className="flex items-center gap-2 px-5 py-2 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl font-bold text-sm hover:scale-105 transition-transform"
          >
            {isGeneratingZip ? <Loader2 className="w-4 h-4 animate-spin" /> : <Archive className="w-4 h-4" />}
            Export Kit
          </button>
        </div>

        <main className="p-4 sm:p-8 lg:p-12 max-w-6xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={`${concept.id}-${activeTab}`}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="space-y-12"
            >
              {/* Active Tab Content */}
              {activeTab === 'logos' && (
                <section className="space-y-8">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <h2 className="text-3xl font-bold text-slate-900 dark:text-white tracking-tight">Logo Variations</h2>
                      <p className="text-slate-500 dark:text-slate-400 mt-1">{concept.description}</p>
                    </div>
                    <div className="flex items-center gap-3 bg-white dark:bg-slate-900 p-2 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm self-start">
                      <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest pl-2">Animated</span>
                      <button 
                        onClick={() => setIsAnimated(!isAnimated)}
                        className={`w-10 h-5 rounded-full transition-colors relative ${isAnimated ? 'bg-blue-600' : 'bg-slate-200 dark:bg-slate-800'}`}
                      >
                        <div className={`w-3 h-3 bg-white rounded-full absolute top-1 transition-transform ${isAnimated ? 'translate-x-6' : 'translate-x-1'}`} />
                      </button>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <LogoCard title="Primary Light" concept={concept} layout="horizontal" theme="light" id={`logo-${concept.id}-primary-light`} isAnimated={isAnimated} />
                    <LogoCard title="Primary Dark" concept={concept} layout="horizontal" theme="dark" id={`logo-${concept.id}-primary-dark`} isAnimated={isAnimated} />
                    <LogoCard title="Stacked" concept={concept} layout="stacked" theme={appTheme} id={`logo-${concept.id}-stacked-${appTheme}`} isAnimated={isAnimated} />
                    <LogoCard title="Compact" concept={concept} layout="compact" theme={appTheme} id={`logo-${concept.id}-compact-${appTheme}`} isAnimated={isAnimated} />
                    <div className="grid grid-cols-2 gap-6">
                      <LogoCard title="Icon" concept={concept} layout="icon" theme={appTheme} id={`logo-${concept.id}-icon-${appTheme}`} isAnimated={isAnimated} />
                      <LogoCard title="Wordmark" concept={concept} layout="wordmark" theme={appTheme} id={`logo-${concept.id}-wordmark-${appTheme}`} isAnimated={isAnimated} />
                    </div>
                    <LogoCard title="Badge" concept={concept} layout="badge" theme={appTheme} id={`logo-${concept.id}-badge-${appTheme}`} isAnimated={isAnimated} />
                  </div>
                </section>
              )}

              {activeTab === 'social' && (
                <section className="space-y-8">
                  <div>
                    <h2 className="text-3xl font-bold text-slate-900 dark:text-white tracking-tight">Social Media</h2>
                    <p className="text-slate-500 dark:text-slate-400 mt-1">Ready-to-use assets for your social presence.</p>
                  </div>
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-1">
                      <SocialAssetCard title="Profile" dimensions="1080x1080" concept={concept} type="profile" id={`social-${concept.id}-profile`} aspectClass="aspect-square" />
                    </div>
                    <div className="lg:col-span-2 space-y-8">
                      <SocialAssetCard title="Twitter Banner" dimensions="1500x500" concept={concept} type="banner-twitter" id={`social-${concept.id}-twitter`} aspectClass="aspect-[3/1]" />
                      <SocialAssetCard title="LinkedIn Banner" dimensions="1584x396" concept={concept} type="banner-linkedin" id={`social-${concept.id}-linkedin`} aspectClass="aspect-[4/1]" />
                    </div>
                  </div>
                </section>
              )}

              {activeTab === 'colors' && (
                <section className="space-y-8">
                  <div>
                    <h2 className="text-3xl font-bold text-slate-900 dark:text-white tracking-tight">Color Palette</h2>
                    <p className="text-slate-500 dark:text-slate-400 mt-1">The core colors that define the {concept.name} identity.</p>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6">
                    {concept.colors.map((color, idx) => (
                      <ColorSwatch key={idx} color={color} />
                    ))}
                  </div>
                </section>
              )}

              {activeTab === 'typography' && (
                <section className="space-y-8">
                  <div>
                    <h2 className="text-3xl font-bold text-slate-900 dark:text-white tracking-tight">Typography</h2>
                    <p className="text-slate-500 dark:text-slate-400 mt-1">Fonts selected for maximum professional impact.</p>
                  </div>
                  <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 sm:p-12 transition-colors shadow-sm">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
                      <div className="space-y-6">
                        <div className="inline-flex px-3 py-1 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 text-[10px] font-bold uppercase tracking-widest rounded-full">Primary</div>
                        <div className={`text-5xl sm:text-7xl text-slate-900 dark:text-white leading-none ${concept.fontClass.includes('display') ? 'font-display' : 'font-sans'}`}>
                          {concept.fontClass.includes('display') ? 'Space Grotesk' : 'Inter'}
                        </div>
                        <p className="text-slate-500 dark:text-slate-400 max-w-md">Used for high-impact brand moments, logos, and primary headings.</p>
                        <div className={`text-2xl sm:text-3xl text-slate-800 dark:text-slate-200 break-all leading-tight ${concept.fontClass.includes('display') ? 'font-display' : 'font-sans'}`}>
                          AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz
                        </div>
                      </div>
                      <div className="space-y-6">
                        <div className="inline-flex px-3 py-1 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 text-[10px] font-bold uppercase tracking-widest rounded-full">Secondary</div>
                        <div className="text-5xl sm:text-7xl font-sans text-slate-900 dark:text-white leading-none">Inter</div>
                        <p className="text-slate-500 dark:text-slate-400 max-w-md">The workhorse font for body copy, UI elements, and technical documentation.</p>
                        <div className="text-2xl sm:text-3xl font-sans text-slate-800 dark:text-slate-200 break-all leading-tight">
                          AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz
                        </div>
                      </div>
                    </div>
                  </div>
                </section>
              )}

              {activeTab === 'mobile' && (
                <section className="space-y-8">
                  <div className="max-w-4xl">
                    <h2 className="text-3xl font-bold text-slate-900 dark:text-white tracking-tight flex items-center gap-3">
                      <Smartphone className="w-8 h-8 text-blue-600" />
                      Mobile-First SaaS
                    </h2>
                    <p className="text-slate-500 dark:text-slate-400 mt-2 text-lg">
                      Optimized for frictionless, on-the-go assessments. Our brand identity is built to shine on small screens.
                    </p>
                  </div>
                  
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                    <div className="order-2 lg:order-1 space-y-8">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        {[
                          { icon: Zap, title: "Fast Performance", desc: "Lightweight SVG assets for instant mobile loading." },
                          { icon: Shield, title: "Trustworthy", desc: "Clean lines that maintain clarity at any resolution." },
                          { icon: Rocket, title: "Scalable", desc: "Vector-perfect branding for responsive SaaS layouts." },
                          { icon: Smartphone, title: "Touch Ready", desc: "Iconography designed for effortless interaction." }
                        ].map((feature, i) => (
                          <div key={i} className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
                            <div className="w-10 h-10 bg-blue-50 dark:bg-blue-900/20 rounded-xl flex items-center justify-center mb-4">
                              <feature.icon className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                            </div>
                            <h3 className="font-bold text-slate-900 dark:text-white mb-1">{feature.title}</h3>
                            <p className="text-xs text-slate-500 dark:text-slate-400">{feature.desc}</p>
                          </div>
                        ))}
                      </div>
                      <div className="p-8 bg-blue-600 rounded-3xl text-white shadow-xl shadow-blue-600/20">
                        <h3 className="text-xl font-bold mb-2">Ready for the App Store?</h3>
                        <p className="text-blue-100 mb-6 text-sm">Download the mobile-optimized asset pack including app icons and splash screens.</p>
                        <button className="px-6 py-3 bg-white text-blue-600 rounded-xl font-bold text-sm hover:bg-blue-50 transition-colors">
                          Download Mobile Assets
                        </button>
                      </div>
                    </div>
                    <div className="order-1 lg:order-2 flex justify-center">
                      <MobileMockup concept={concept} theme={appTheme} />
                    </div>
                  </div>
                </section>
              )}
            </motion.div>
          </AnimatePresence>
        </main>

        {/* Mobile Bottom Navigation */}
        <nav className="lg:hidden fixed bottom-0 inset-x-0 bg-white/80 dark:bg-slate-900/80 backdrop-blur-lg border-t border-slate-200 dark:border-slate-800 h-20 flex items-center justify-around px-4 z-30 transition-colors">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center gap-1 transition-all ${
                activeTab === item.id ? 'text-blue-600' : 'text-slate-400'
              }`}
            >
              <item.icon className={`w-6 h-6 ${activeTab === item.id ? 'scale-110' : ''}`} />
              <span className="text-[10px] font-bold uppercase tracking-tighter">{item.label}</span>
            </button>
          ))}
        </nav>
      </div>
    </div>
  );
}
